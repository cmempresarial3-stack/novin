# Overview

This is a Christian mobile application built with React Native + Expo, designed to provide spiritual comfort and guidance with the core message "Você não está sozinho, viva com propósito" (You are not alone, live with purpose). The app features daily Bible verses, devotionals, complete Bible reader, hymn player, intelligent push notifications, user profiles, and a modern dark/light theme system.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Mobile Architecture
The app uses React Native + Expo for cross-platform mobile development:
- **React Native 0.81.4** with Expo SDK 54 for native mobile functionality
- **React Navigation** for seamless navigation between screens
- **NativeWind (Tailwind CSS)** for consistent styling across platforms
- **AsyncStorage** for local data persistence
- **Context API** for state management (theme, user preferences)
- **Native Icons** using react-native-vector-icons

The app follows a tab-based navigation pattern with professional, modern, and minimalist design.

## Core Features Implementation
- **Daily Verse Algorithm**: Device-based deterministic selection ensuring users get the same verse per day
- **Intelligent Push Notifications**: Contextual questions 2-3x per week with mood-based verse responses
- **Dual Theme System**: Light and dark themes with blue, gold, and graphite color scheme
- **User Profile Management**: Local photo storage and name persistence
- **Font Size Controls**: Adjustable text size for Bible and hymns reading
- **WebView Store Integration**: Embedded store functionality
- **Social Media Integration**: Direct links to Instagram, YouTube, and Facebook
- **Email Feedback System**: Direct suggestion submissions to company email

## Data Storage Solutions
Implements a local-first approach with offline functionality:
- **AsyncStorage**: User preferences, profile data, theme settings, and app configurations
- **JSON Data Files**: Bible content (ACF), hymns (Harpa Cristã), verses, and devotionals
- **Local Image Storage**: Profile pictures stored on device
- **No Cloud Dependencies**: Full offline functionality for core features

## Navigation Structure
- **Home Tab**: Daily verse, store integration, social media links, motivational content
- **Bible Tab**: Complete ACF Bible with search, font controls, and verse navigation
- **Hymns Tab**: Full Harpa Cristã hymnal with search and font adjustments
- **Store Tab**: WebView integration for Christian products
- **Settings Tab**: User profile, theme toggle, notifications, feedback system

## Notification System
- **Daily Verse Notifications**: Scheduled for 8:00 AM daily
- **Intelligent Questions**: Tuesday, Thursday, Saturday at 7:00 PM
- **Mood-Based Responses**: Contextual verse selection based on user responses
- **Permission Management**: Graceful handling of notification permissions

# External Dependencies

## Core Dependencies
- **Expo SDK 54** for development platform and native APIs
- **React Native 0.81.4** for mobile app framework
- **React Navigation** for app navigation (Bottom Tabs + Stack)
- **NativeWind** for Tailwind CSS styling in React Native
- **AsyncStorage** for local data persistence

## Expo Modules
- **expo-notifications** for intelligent push notification system
- **expo-image-picker** for profile photo functionality
- **expo-mail-composer** for feedback system
- **expo-web-browser** for social media links
- **expo-constants** and **expo-device** for app configuration

## UI and Styling
- **react-native-vector-icons** for consistent iconography
- **react-native-paper** for Material Design components
- **react-native-webview** for embedded store functionality
- **react-native-safe-area-context** for proper screen handling

## Development Tools
- **TypeScript** for type safety and better development experience
- **Metro Bundler** for React Native bundling
- **EAS Build** configuration for APK/IPA generation
- **Tailwind CSS** with NativeWind preset for styling

## Content Sources
- **Almeida Corrigida Fiel (ACF) Bible**: Complete Portuguese Bible translation
- **Harpa Cristã**: Traditional Christian hymnal (611 hymns)
- **Daily Verses**: Curated collection of inspirational Bible verses
- **Daily Devotionals**: Custom spiritual guidance content

# Build Configuration

## APK Generation (Android)
1. Install EAS CLI: `npm install -g @expo/cli`
2. Configure build: `eas build:configure`
3. Build APK: `eas build --platform android --profile preview`

## IPA Generation (iOS)
1. Ensure Apple Developer account setup
2. Configure iOS bundle identifier in app.json
3. Build IPA: `eas build --platform ios --profile preview`

The application maintains a local-first, privacy-focused approach with no server dependencies, ensuring users can access spiritual content offline while receiving intelligent, contextual guidance through push notifications.