import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const UserContext = createContext();

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

export const UserProvider = ({ children }) => {
  const [userName, setUserName] = useState('');
  const [userPhoto, setUserPhoto] = useState(null);
  const [isFirstTime, setIsFirstTime] = useState(true);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const savedName = await AsyncStorage.getItem('userName');
      const savedPhoto = await AsyncStorage.getItem('userPhoto');
      const hasSetupBefore = await AsyncStorage.getItem('hasSetupBefore');

      if (savedName) {
        setUserName(savedName);
      }
      if (savedPhoto) {
        setUserPhoto(savedPhoto);
      }
      setIsFirstTime(!hasSetupBefore);
    } catch (error) {
      console.error('Erro ao carregar dados do usuário:', error);
    }
  };

  const saveUserName = async (name) => {
    try {
      await AsyncStorage.setItem('userName', name);
      await AsyncStorage.setItem('hasSetupBefore', 'true');
      setUserName(name);
      setIsFirstTime(false);
    } catch (error) {
      console.error('Erro ao salvar nome do usuário:', error);
    }
  };

  const saveUserPhoto = async (photoUri) => {
    try {
      await AsyncStorage.setItem('userPhoto', photoUri);
      setUserPhoto(photoUri);
    } catch (error) {
      console.error('Erro ao salvar foto do usuário:', error);
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) {
      return `Bom dia, ${userName || 'amigo'}!`;
    } else if (hour < 18) {
      return `Boa tarde, ${userName || 'amigo'}!`;
    } else {
      return `Boa noite, ${userName || 'amigo'}!`;
    }
  };

  const value = {
    userName,
    userPhoto,
    isFirstTime,
    saveUserName,
    saveUserPhoto,
    getGreeting,
  };

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
};