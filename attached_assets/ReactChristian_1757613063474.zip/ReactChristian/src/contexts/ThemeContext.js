import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ThemeContext = createContext();

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

export const ThemeProvider = ({ children }) => {
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    loadThemePreference();
  }, []);

  const loadThemePreference = async () => {
    try {
      const savedTheme = await AsyncStorage.getItem('theme');
      if (savedTheme !== null) {
        setIsDarkMode(savedTheme === 'dark');
      }
    } catch (error) {
      console.error('Erro ao carregar preferência de tema:', error);
    }
  };

  const toggleTheme = async () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    try {
      await AsyncStorage.setItem('theme', newTheme ? 'dark' : 'light');
    } catch (error) {
      console.error('Erro ao salvar preferência de tema:', error);
    }
  };

  const value = {
    isDarkMode,
    toggleTheme,
    theme: isDarkMode ? darkTheme : lightTheme,
  };

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};

const lightTheme = {
  background: '#ffffff',
  surface: '#f8fafc',
  primary: '#0070f3',
  primaryLight: '#bae0ff',
  secondary: '#eab308',
  text: '#0f172a',
  textSecondary: '#64748b',
  border: '#e2e8f0',
  card: '#ffffff',
  accent: '#facc15',
};

const darkTheme = {
  background: '#000000',
  surface: '#1a1a1a',
  primary: '#36abff',
  primaryLight: '#1a1a1a',
  secondary: '#fde047',
  text: '#ffffff',
  textSecondary: '#a0a0a0',
  border: '#333333',
  card: '#1a1a1a',
  accent: '#facc15',
};