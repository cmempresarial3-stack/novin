import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  TouchableOpacity, 
  StyleSheet,
  TextInput,
  FlatList 
} from 'react-native';
import { useTheme } from '../contexts/ThemeContext';
import { MaterialIcons } from '@expo/vector-icons';
import { storage, StorageKeys } from '../utils/storage';
import hymnsData from '../data/harpa-crista.json';

export default function HymnsScreen() {
  const { theme } = useTheme();
  const [hymns, setHymns] = useState([]);
  const [selectedHymn, setSelectedHymn] = useState(null);
  const [searchText, setSearchText] = useState('');
  const [fontSize, setFontSize] = useState(16);

  useEffect(() => {
    loadHymns();
    loadFontSize();
  }, []);

  const loadFontSize = async () => {
    const savedSize = await storage.getItem(StorageKeys.READING_PREFERENCES);
    if (savedSize && savedSize.hymnsFontSize) {
      setFontSize(savedSize.hymnsFontSize);
    }
  };

  const saveFontSize = async (newSize) => {
    const preferences = await storage.getItem(StorageKeys.READING_PREFERENCES) || {};
    preferences.hymnsFontSize = newSize;
    await storage.setItem(StorageKeys.READING_PREFERENCES, preferences);
  };

  const loadHymns = () => {
    if (hymnsData && hymnsData.hymns) {
      setHymns(hymnsData.hymns);
    }
  };

  const selectHymn = (hymn) => {
    setSelectedHymn(hymn);
  };

  const goBack = () => {
    setSelectedHymn(null);
  };

  const adjustFontSize = async (increase) => {
    const newSize = increase ? fontSize + 1 : fontSize - 1;
    if (newSize >= 12 && newSize <= 24) {
      setFontSize(newSize);
      await saveFontSize(newSize);
    }
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: 15,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    backButton: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    backText: {
      color: theme.primary,
      fontSize: 16,
      marginLeft: 5,
    },
    fontControls: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    fontButton: {
      padding: 8,
      marginHorizontal: 5,
      backgroundColor: theme.surface,
      borderRadius: 20,
    },
    fontSizeText: {
      color: theme.text,
      fontSize: 14,
      marginHorizontal: 10,
    },
    searchContainer: {
      padding: 15,
    },
    searchInput: {
      backgroundColor: theme.surface,
      borderRadius: 25,
      paddingHorizontal: 20,
      paddingVertical: 12,
      fontSize: 16,
      color: theme.text,
      borderWidth: 1,
      borderColor: theme.border,
    },
    listContainer: {
      padding: 15,
    },
    hymnItem: {
      backgroundColor: theme.card,
      padding: 20,
      marginVertical: 5,
      borderRadius: 10,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.1,
      shadowRadius: 2,
      elevation: 2,
    },
    hymnNumber: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.primary,
      marginRight: 15,
      minWidth: 40,
    },
    hymnTitle: {
      fontSize: 16,
      fontWeight: '600',
      color: theme.text,
      flex: 1,
    },
    hymnContainer: {
      padding: 20,
    },
    hymnTitleLarge: {
      fontSize: 24,
      fontWeight: 'bold',
      color: theme.text,
      textAlign: 'center',
      marginBottom: 20,
    },
    hymnNumberLarge: {
      fontSize: 18,
      color: theme.primary,
      textAlign: 'center',
      marginBottom: 10,
    },
    verseContainer: {
      marginVertical: 15,
    },
    verseText: {
      fontSize: fontSize,
      color: theme.text,
      lineHeight: fontSize * 1.6,
      textAlign: 'left',
    },
    chorusContainer: {
      backgroundColor: theme.surface,
      padding: 15,
      borderRadius: 10,
      marginVertical: 10,
      borderLeftWidth: 4,
      borderLeftColor: theme.secondary,
    },
    chorusLabel: {
      fontSize: 14,
      fontWeight: 'bold',
      color: theme.primary,
      marginBottom: 8,
    },
  });

  const renderHymnItem = ({ item }) => (
    <TouchableOpacity style={styles.hymnItem} onPress={() => selectHymn(item)}>
      <Text style={styles.hymnNumber}>{item.number}</Text>
      <Text style={styles.hymnTitle}>{item.title}</Text>
      <MaterialIcons name="arrow-forward-ios" size={20} color={theme.textSecondary} />
    </TouchableOpacity>
  );

  const filteredHymns = hymns.filter(hymn =>
    hymn.title.toLowerCase().includes(searchText.toLowerCase()) ||
    hymn.number.toString().includes(searchText)
  );

  return (
    <View style={styles.container}>
      {/* Header com controles */}
      <View style={styles.header}>
        {selectedHymn && (
          <TouchableOpacity style={styles.backButton} onPress={goBack}>
            <MaterialIcons name="arrow-back" size={24} color={theme.primary} />
            <Text style={styles.backText}>Voltar</Text>
          </TouchableOpacity>
        )}
        
        {selectedHymn && (
          <View style={styles.fontControls}>
            <TouchableOpacity 
              style={styles.fontButton} 
              onPress={() => adjustFontSize(false)}
            >
              <Text style={[styles.fontSizeText, { fontSize: 12 }]}>A-</Text>
            </TouchableOpacity>
            <Text style={styles.fontSizeText}>{fontSize}px</Text>
            <TouchableOpacity 
              style={styles.fontButton} 
              onPress={() => adjustFontSize(true)}
            >
              <Text style={[styles.fontSizeText, { fontSize: 18 }]}>A+</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Lista de hinos */}
      {!selectedHymn && (
        <>
          <View style={styles.searchContainer}>
            <TextInput
              style={styles.searchInput}
              placeholder="Buscar hino pelo nome ou número..."
              placeholderTextColor={theme.textSecondary}
              value={searchText}
              onChangeText={setSearchText}
            />
          </View>
          <FlatList
            data={filteredHymns}
            renderItem={renderHymnItem}
            keyExtractor={(item) => item.number.toString()}
            contentContainerStyle={styles.listContainer}
            showsVerticalScrollIndicator={false}
          />
        </>
      )}

      {/* Exibição do hino selecionado */}
      {selectedHymn && (
        <ScrollView style={styles.hymnContainer}>
          <Text style={styles.hymnNumberLarge}>
            Hino {selectedHymn.number}
          </Text>
          <Text style={styles.hymnTitleLarge}>
            {selectedHymn.title}
          </Text>

          {selectedHymn.verses.map((verse, index) => (
            <View key={index} style={styles.verseContainer}>
              <Text style={styles.verseText}>{verse}</Text>
            </View>
          ))}

          {selectedHymn.chorus && (
            <View style={styles.chorusContainer}>
              <Text style={styles.chorusLabel}>Coro:</Text>
              <Text style={[styles.verseText, { fontSize: fontSize }]}>
                {selectedHymn.chorus}
              </Text>
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}