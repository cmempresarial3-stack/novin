import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  TouchableOpacity, 
  StyleSheet,
  TextInput,
  Switch,
  Alert,
  Image
} from 'react-native';
import { useTheme } from '../contexts/ThemeContext';
import { MaterialIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as MailComposer from 'expo-mail-composer';
import { storage, StorageKeys } from '../utils/storage';

export default function SettingsScreen() {
  const { theme, isDarkMode, toggleTheme } = useTheme();
  const [userProfile, setUserProfile] = useState({
    name: '',
    profileImage: null,
  });
  const [feedbackText, setFeedbackText] = useState('');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  useEffect(() => {
    loadUserProfile();
  }, []);

  const loadUserProfile = async () => {
    const profile = await storage.getItem(StorageKeys.USER_PROFILE);
    if (profile) {
      setUserProfile(profile);
    }
  };

  const saveUserProfile = async (newProfile) => {
    setUserProfile(newProfile);
    await storage.setItem(StorageKeys.USER_PROFILE, newProfile);
  };

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    
    if (status !== 'granted') {
      Alert.alert(
        'Permissão necessária',
        'Precisamos de permissão para acessar sua galeria de fotos.'
      );
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.5,
    });

    if (!result.canceled) {
      const newProfile = { ...userProfile, profileImage: result.assets[0].uri };
      saveUserProfile(newProfile);
    }
  };

  const updateName = (name) => {
    const newProfile = { ...userProfile, name };
    saveUserProfile(newProfile);
  };

  const sendFeedback = async () => {
    if (!feedbackText.trim()) {
      Alert.alert('Atenção', 'Por favor, escreva sua sugestão antes de enviar.');
      return;
    }

    try {
      const isAvailable = await MailComposer.isAvailableAsync();
      
      if (isAvailable) {
        await MailComposer.composeAsync({
          recipients: ['contato@exemploapp.com'], // Substitua pelo e-mail da empresa
          subject: 'Sugestão do App Cristão',
          body: `Nome: ${userProfile.name || 'Não informado'}\n\nSugestão:\n${feedbackText}`,
        });
        
        setFeedbackText('');
        Alert.alert('Obrigado!', 'Sua sugestão foi enviada com sucesso.');
      } else {
        Alert.alert(
          'Erro',
          'Não foi possível abrir o cliente de e-mail. Verifique se você tem um app de e-mail configurado.'
        );
      }
    } catch (error) {
      console.error('Erro ao enviar feedback:', error);
      Alert.alert('Erro', 'Não foi possível enviar sua sugestão. Tente novamente.');
    }
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    content: {
      padding: 20,
    },
    section: {
      marginBottom: 30,
    },
    sectionTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 15,
    },
    profileSection: {
      alignItems: 'center',
      marginBottom: 30,
    },
    profileImageContainer: {
      position: 'relative',
      marginBottom: 20,
    },
    profileImage: {
      width: 100,
      height: 100,
      borderRadius: 50,
      backgroundColor: theme.surface,
    },
    profileImagePlaceholder: {
      width: 100,
      height: 100,
      borderRadius: 50,
      backgroundColor: theme.surface,
      justifyContent: 'center',
      alignItems: 'center',
      borderWidth: 2,
      borderColor: theme.border,
      borderStyle: 'dashed',
    },
    editImageButton: {
      position: 'absolute',
      bottom: 0,
      right: 0,
      backgroundColor: theme.primary,
      width: 32,
      height: 32,
      borderRadius: 16,
      justifyContent: 'center',
      alignItems: 'center',
      borderWidth: 2,
      borderColor: theme.background,
    },
    nameInput: {
      backgroundColor: theme.surface,
      borderRadius: 10,
      paddingHorizontal: 15,
      paddingVertical: 12,
      fontSize: 16,
      color: theme.text,
      borderWidth: 1,
      borderColor: theme.border,
      textAlign: 'center',
      minWidth: 200,
    },
    settingItem: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingVertical: 15,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    settingLabel: {
      fontSize: 16,
      color: theme.text,
      flex: 1,
    },
    settingDescription: {
      fontSize: 14,
      color: theme.textSecondary,
      marginTop: 5,
    },
    feedbackContainer: {
      marginTop: 10,
    },
    feedbackInput: {
      backgroundColor: theme.surface,
      borderRadius: 10,
      paddingHorizontal: 15,
      paddingVertical: 12,
      fontSize: 16,
      color: theme.text,
      borderWidth: 1,
      borderColor: theme.border,
      height: 100,
      textAlignVertical: 'top',
      marginBottom: 15,
    },
    sendButton: {
      backgroundColor: theme.primary,
      paddingVertical: 12,
      paddingHorizontal: 30,
      borderRadius: 25,
      alignItems: 'center',
    },
    sendButtonText: {
      color: '#ffffff',
      fontSize: 16,
      fontWeight: 'bold',
    },
  });

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        {/* Perfil do Usuário */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Meu Perfil</Text>
          <View style={styles.profileSection}>
            <View style={styles.profileImageContainer}>
              {userProfile.profileImage ? (
                <Image source={{ uri: userProfile.profileImage }} style={styles.profileImage} />
              ) : (
                <View style={styles.profileImagePlaceholder}>
                  <MaterialIcons name="person" size={40} color={theme.textSecondary} />
                </View>
              )}
              <TouchableOpacity style={styles.editImageButton} onPress={pickImage}>
                <MaterialIcons name="camera-alt" size={16} color="#ffffff" />
              </TouchableOpacity>
            </View>
            
            <TextInput
              style={styles.nameInput}
              placeholder="Digite seu nome"
              placeholderTextColor={theme.textSecondary}
              value={userProfile.name}
              onChangeText={updateName}
            />
          </View>
        </View>

        {/* Configurações */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Configurações</Text>
          
          <View style={styles.settingItem}>
            <View style={{ flex: 1 }}>
              <Text style={styles.settingLabel}>Tema Escuro</Text>
              <Text style={styles.settingDescription}>
                Ativar tema escuro com cores azul escuro, cinza grafite e dourado
              </Text>
            </View>
            <Switch
              value={isDarkMode}
              onValueChange={toggleTheme}
              trackColor={{ false: theme.border, true: theme.primary }}
              thumbColor={isDarkMode ? '#ffffff' : theme.surface}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={{ flex: 1 }}>
              <Text style={styles.settingLabel}>Notificações</Text>
              <Text style={styles.settingDescription}>
                Receber versículos diários e perguntas motivacionais
              </Text>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              trackColor={{ false: theme.border, true: theme.primary }}
              thumbColor={notificationsEnabled ? '#ffffff' : theme.surface}
            />
          </View>
        </View>

        {/* Feedback */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Envie sua Sugestão</Text>
          <View style={styles.feedbackContainer}>
            <TextInput
              style={styles.feedbackInput}
              placeholder="Compartilhe suas ideias para melhorar o app..."
              placeholderTextColor={theme.textSecondary}
              value={feedbackText}
              onChangeText={setFeedbackText}
              multiline
            />
            <TouchableOpacity style={styles.sendButton} onPress={sendFeedback}>
              <Text style={styles.sendButtonText}>Enviar Sugestão</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}