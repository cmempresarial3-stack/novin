import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  TouchableOpacity, 
  StyleSheet,
  TextInput,
  FlatList 
} from 'react-native';
import { useTheme } from '../contexts/ThemeContext';
import { MaterialIcons } from '@expo/vector-icons';
import { storage, StorageKeys } from '../utils/storage';
import bibleData from '../data/bible-acf.json';

export default function BibleScreen() {
  const { theme } = useTheme();
  const [books, setBooks] = useState([]);
  const [selectedBook, setSelectedBook] = useState(null);
  const [selectedChapter, setSelectedChapter] = useState(null);
  const [searchText, setSearchText] = useState('');
  const [fontSize, setFontSize] = useState(16);

  useEffect(() => {
    loadBooks();
    loadFontSize();
  }, []);

  const loadFontSize = async () => {
    const savedSize = await storage.getItem(StorageKeys.READING_PREFERENCES);
    if (savedSize && savedSize.bibleFontSize) {
      setFontSize(savedSize.bibleFontSize);
    }
  };

  const saveFontSize = async (newSize) => {
    const preferences = await storage.getItem(StorageKeys.READING_PREFERENCES) || {};
    preferences.bibleFontSize = newSize;
    await storage.setItem(StorageKeys.READING_PREFERENCES, preferences);
  };

  const loadBooks = () => {
    if (bibleData && bibleData.books) {
      setBooks(bibleData.books);
    }
  };

  const selectBook = (book) => {
    setSelectedBook(book);
    setSelectedChapter(null);
  };

  const selectChapter = (chapterNumber) => {
    const chapter = selectedBook.chapters.find(ch => ch.chapter === chapterNumber);
    setSelectedChapter(chapter);
  };

  const goBack = () => {
    if (selectedChapter) {
      setSelectedChapter(null);
    } else if (selectedBook) {
      setSelectedBook(null);
    }
  };

  const adjustFontSize = async (increase) => {
    const newSize = increase ? fontSize + 1 : fontSize - 1;
    if (newSize >= 12 && newSize <= 24) {
      setFontSize(newSize);
      await saveFontSize(newSize);
    }
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: 15,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    backButton: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    backText: {
      color: theme.primary,
      fontSize: 16,
      marginLeft: 5,
    },
    fontControls: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    fontButton: {
      padding: 8,
      marginHorizontal: 5,
      backgroundColor: theme.surface,
      borderRadius: 20,
    },
    fontSizeText: {
      color: theme.text,
      fontSize: 14,
      marginHorizontal: 10,
    },
    searchContainer: {
      padding: 15,
    },
    searchInput: {
      backgroundColor: theme.surface,
      borderRadius: 25,
      paddingHorizontal: 20,
      paddingVertical: 12,
      fontSize: 16,
      color: theme.text,
      borderWidth: 1,
      borderColor: theme.border,
    },
    listContainer: {
      padding: 15,
    },
    bookItem: {
      backgroundColor: theme.card,
      padding: 20,
      marginVertical: 5,
      borderRadius: 10,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.1,
      shadowRadius: 2,
      elevation: 2,
    },
    bookTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.text,
    },
    bookChapters: {
      fontSize: 14,
      color: theme.textSecondary,
    },
    chapterGrid: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      padding: 15,
    },
    chapterButton: {
      backgroundColor: theme.surface,
      width: 50,
      height: 50,
      borderRadius: 25,
      justifyContent: 'center',
      alignItems: 'center',
      margin: 5,
      borderWidth: 1,
      borderColor: theme.border,
    },
    chapterButtonText: {
      color: theme.text,
      fontSize: 16,
      fontWeight: '500',
    },
    verseContainer: {
      padding: 20,
    },
    chapterTitle: {
      fontSize: 22,
      fontWeight: 'bold',
      color: theme.text,
      textAlign: 'center',
      marginBottom: 20,
    },
    verseItem: {
      flexDirection: 'row',
      marginVertical: 8,
      paddingRight: 10,
    },
    verseNumber: {
      fontSize: fontSize - 2,
      color: theme.primary,
      fontWeight: 'bold',
      marginRight: 10,
      minWidth: 30,
    },
    verseText: {
      fontSize: fontSize,
      color: theme.text,
      lineHeight: fontSize * 1.5,
      flex: 1,
    },
  });

  const renderBookItem = ({ item }) => (
    <TouchableOpacity style={styles.bookItem} onPress={() => selectBook(item)}>
      <View>
        <Text style={styles.bookTitle}>{item.name}</Text>
        <Text style={styles.bookChapters}>
          {item.chapters.length} capítulos
        </Text>
      </View>
      <MaterialIcons name="arrow-forward-ios" size={20} color={theme.textSecondary} />
    </TouchableOpacity>
  );

  const renderVerse = ({ item }) => (
    <View style={styles.verseItem}>
      <Text style={styles.verseNumber}>{item.verse}</Text>
      <Text style={styles.verseText}>{item.text}</Text>
    </View>
  );

  const filteredBooks = books.filter(book =>
    book.name.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <View style={styles.container}>
      {/* Header com controles */}
      <View style={styles.header}>
        {(selectedBook || selectedChapter) && (
          <TouchableOpacity style={styles.backButton} onPress={goBack}>
            <MaterialIcons name="arrow-back" size={24} color={theme.primary} />
            <Text style={styles.backText}>Voltar</Text>
          </TouchableOpacity>
        )}
        
        {selectedChapter && (
          <View style={styles.fontControls}>
            <TouchableOpacity 
              style={styles.fontButton} 
              onPress={() => adjustFontSize(false)}
            >
              <Text style={[styles.fontSizeText, { fontSize: 12 }]}>A-</Text>
            </TouchableOpacity>
            <Text style={styles.fontSizeText}>{fontSize}px</Text>
            <TouchableOpacity 
              style={styles.fontButton} 
              onPress={() => adjustFontSize(true)}
            >
              <Text style={[styles.fontSizeText, { fontSize: 18 }]}>A+</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Lista de livros */}
      {!selectedBook && (
        <>
          <View style={styles.searchContainer}>
            <TextInput
              style={styles.searchInput}
              placeholder="Buscar livro da Bíblia..."
              placeholderTextColor={theme.textSecondary}
              value={searchText}
              onChangeText={setSearchText}
            />
          </View>
          <FlatList
            data={filteredBooks}
            renderItem={renderBookItem}
            keyExtractor={(item) => item.name}
            contentContainerStyle={styles.listContainer}
            showsVerticalScrollIndicator={false}
          />
        </>
      )}

      {/* Seleção de capítulos */}
      {selectedBook && !selectedChapter && (
        <ScrollView>
          <Text style={[styles.chapterTitle, { marginTop: 20 }]}>
            {selectedBook.name}
          </Text>
          <View style={styles.chapterGrid}>
            {selectedBook.chapters.map((chapter) => (
              <TouchableOpacity
                key={chapter.chapter}
                style={styles.chapterButton}
                onPress={() => selectChapter(chapter.chapter)}
              >
                <Text style={styles.chapterButtonText}>
                  {chapter.chapter}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      )}

      {/* Leitura do capítulo */}
      {selectedChapter && (
        <ScrollView style={styles.verseContainer}>
          <Text style={styles.chapterTitle}>
            {selectedBook.name} {selectedChapter.chapter}
          </Text>
          <FlatList
            data={selectedChapter.verses}
            renderItem={renderVerse}
            keyExtractor={(item) => item.verse.toString()}
            scrollEnabled={false}
          />
        </ScrollView>
      )}
    </View>
  );
}