import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  TouchableOpacity, 
  StyleSheet,
  Dimensions,
  Image 
} from 'react-native';
import { useTheme } from '../contexts/ThemeContext';
import { MaterialIcons } from '@expo/vector-icons';
import * as Linking from 'expo-linking';
import { useNavigation } from '@react-navigation/native';
import { storage, StorageKeys } from '../utils/storage';
import verses from '../data/verses.json';
import devotionals from '../data/devotionals.json';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const { theme } = useTheme();
  const [dailyVerse, setDailyVerse] = useState(null);
  const [dailyDevotional, setDailyDevotional] = useState(null);
  const [userName, setUserName] = useState('');

  useEffect(() => {
    loadDailyContent();
    loadUserName();
  }, []);

  const loadUserName = async () => {
    try {
      const userProfile = await storage.getItem(StorageKeys.USER_PROFILE);
      if (userProfile && userProfile.name) {
        setUserName(userProfile.name);
      }
    } catch (error) {
      console.error('Erro ao carregar nome do usuário:', error);
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    const name = userName || 'amigo';
    
    if (hour < 12) {
      return `Bom dia, ${name}!`;
    } else if (hour < 18) {
      return `Boa tarde, ${name}!`;
    } else {
      return `Boa noite, ${name}!`;
    }
  };

  const loadDailyContent = () => {
    const today = new Date();
    const dayOfYear = Math.floor((today - new Date(today.getFullYear(), 0, 0)) / 1000 / 60 / 60 / 24);
    
    // Seleciona versículo do dia baseado no dia do ano
    const verseIndex = dayOfYear % verses.length;
    setDailyVerse(verses[verseIndex]);

    // Seleciona devocional do dia
    const devotionalIndex = dayOfYear % devotionals.length;
    setDailyDevotional(devotionals[devotionalIndex]);
  };

  const openSocialMedia = async (platform) => {
    const urls = {
      Instagram: 'https://instagram.com',
      YouTube: 'https://youtube.com',
      Facebook: 'https://facebook.com'
    };
    
    const url = urls[platform];
    if (url) {
      await Linking.openURL(url);
    }
  };

  const navigation = useNavigation();
  
  const openStore = () => {
    navigation.navigate('Loja');
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    welcomeSection: {
      backgroundColor: theme.primary,
      paddingHorizontal: 15,
      paddingVertical: 25,
      borderBottomLeftRadius: 15,
      borderBottomRightRadius: 15,
      marginHorizontal: 5,
    },
    welcomeText: {
      color: '#ffffff',
      fontSize: 24,
      fontWeight: 'bold',
      textAlign: 'center',
      marginBottom: 8,
    },
    motivationalText: {
      color: '#ffffff',
      fontSize: 16,
      textAlign: 'center',
      opacity: 0.9,
    },
    section: {
      paddingHorizontal: 15,
      marginVertical: 15,
    },
    sectionTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 15,
    },
    verseCard: {
      backgroundColor: theme.card,
      padding: 20,
      borderRadius: 15,
      borderLeftWidth: 4,
      borderLeftColor: theme.secondary,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 3,
    },
    verseText: {
      fontSize: 16,
      color: theme.text,
      fontStyle: 'italic',
      lineHeight: 24,
      marginBottom: 10,
    },
    verseReference: {
      fontSize: 14,
      color: theme.primary,
      fontWeight: 'bold',
      textAlign: 'right',
    },
    storeContainer: {
      backgroundColor: theme.card,
      marginHorizontal: 15,
      marginVertical: 10,
      borderRadius: 15,
      overflow: 'hidden',
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 3,
    },
    storeContent: {
      padding: 20,
      flexDirection: 'row',
      alignItems: 'center',
    },
    storeImage: {
      width: 60,
      height: 60,
      borderRadius: 30,
      backgroundColor: theme.primaryLight,
      marginRight: 15,
      alignItems: 'center',
      justifyContent: 'center',
    },
    storeTextContainer: {
      flex: 1,
    },
    storeTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 5,
    },
    storeSubtitle: {
      fontSize: 14,
      color: theme.textSecondary,
    },
    socialSection: {
      paddingHorizontal: 15,
      marginBottom: 20,
    },
    socialContainer: {
      flexDirection: 'row',
      justifyContent: 'space-around',
      marginTop: 15,
    },
    socialButton: {
      alignItems: 'center',
      padding: 15,
    },
    socialIcon: {
      width: 50,
      height: 50,
      borderRadius: 25,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 8,
    },
    socialText: {
      fontSize: 12,
      color: theme.text,
      fontWeight: '500',
    },
  });

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Seção de Boas-vindas */}
      <View style={styles.welcomeSection}>
        <Text style={styles.welcomeText}>{getGreeting()}</Text>
        <Text style={styles.motivationalText}>
          Você não está sozinho, viva com propósito
        </Text>
      </View>

      {/* Versículo do Dia */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Versículo do Dia</Text>
        {dailyVerse && (
          <View style={styles.verseCard}>
            <Text style={styles.verseText}>"{dailyVerse.text}"</Text>
            <Text style={styles.verseReference}>{dailyVerse.reference}</Text>
          </View>
        )}
      </View>

      {/* Container da Loja */}
      <TouchableOpacity style={styles.storeContainer} onPress={openStore}>
        <View style={styles.storeContent}>
          <View style={styles.storeImage}>
            <MaterialIcons name="store" size={30} color={theme.primary} />
          </View>
          <View style={styles.storeTextContainer}>
            <Text style={styles.storeTitle}>Conheça nossa loja</Text>
            <Text style={styles.storeSubtitle}>
              Produtos cristãos selecionados especialmente para você
            </Text>
          </View>
          <MaterialIcons name="arrow-forward-ios" size={20} color={theme.textSecondary} />
        </View>
      </TouchableOpacity>

      {/* Redes Sociais */}
      <View style={styles.socialSection}>
        <Text style={styles.sectionTitle}>Siga-nos</Text>
        <View style={styles.socialContainer}>
          <TouchableOpacity 
            style={styles.socialButton}
            onPress={() => openSocialMedia('Instagram')}
          >
            <View style={[styles.socialIcon, { backgroundColor: '#E4405F' }]}>
              <MaterialIcons name="camera-alt" size={24} color="#ffffff" />
            </View>
            <Text style={styles.socialText}>Instagram</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.socialButton}
            onPress={() => openSocialMedia('YouTube')}
          >
            <View style={[styles.socialIcon, { backgroundColor: '#FF0000' }]}>
              <MaterialIcons name="play-arrow" size={24} color="#ffffff" />
            </View>
            <Text style={styles.socialText}>YouTube</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.socialButton}
            onPress={() => openSocialMedia('Facebook')}
          >
            <View style={[styles.socialIcon, { backgroundColor: '#1877F2' }]}>
              <MaterialIcons name="public" size={24} color="#ffffff" />
            </View>
            <Text style={styles.socialText}>Facebook</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}