import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useTheme } from '../contexts/ThemeContext';
import { MaterialIcons } from '@expo/vector-icons';
import { storage, StorageKeys } from '../utils/storage';

const { width } = Dimensions.get('window');

export default function WelcomeScreen({ onComplete }) {
  const { theme } = useTheme();
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleContinue = async () => {
    if (!name.trim()) {
      Alert.alert('Atenção', 'Por favor, digite seu nome para continuar');
      return;
    }

    setIsLoading(true);
    try {
      // Salva o perfil do usuário com o nome
      const userProfile = {
        name: name.trim(),
        profileImage: null,
        createdAt: new Date().toISOString(),
      };
      
      await storage.setItem(StorageKeys.USER_PROFILE, userProfile);
      await storage.setItem('hasCompletedWelcome', true);
      
      onComplete();
    } catch (error) {
      console.error('Erro ao salvar dados:', error);
      Alert.alert('Erro', 'Não foi possível salvar seus dados. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
      justifyContent: 'center',
      alignItems: 'center',
      paddingHorizontal: 30,
    },
    welcomeIcon: {
      marginBottom: 30,
    },
    title: {
      fontSize: 28,
      fontWeight: 'bold',
      color: theme.text,
      textAlign: 'center',
      marginBottom: 10,
    },
    subtitle: {
      fontSize: 18,
      color: theme.primary,
      textAlign: 'center',
      marginBottom: 40,
      fontWeight: '600',
    },
    description: {
      fontSize: 16,
      color: theme.textSecondary,
      textAlign: 'center',
      marginBottom: 40,
      lineHeight: 24,
    },
    inputContainer: {
      width: '100%',
      marginBottom: 30,
    },
    inputLabel: {
      fontSize: 16,
      color: theme.text,
      marginBottom: 8,
      fontWeight: '500',
    },
    input: {
      backgroundColor: theme.card,
      borderWidth: 2,
      borderColor: theme.border,
      borderRadius: 12,
      paddingHorizontal: 16,
      paddingVertical: 12,
      fontSize: 16,
      color: theme.text,
    },
    inputFocused: {
      borderColor: theme.primary,
    },
    continueButton: {
      backgroundColor: theme.primary,
      paddingVertical: 15,
      paddingHorizontal: 40,
      borderRadius: 12,
      width: '100%',
      alignItems: 'center',
      marginBottom: 20,
    },
    continueButtonDisabled: {
      backgroundColor: theme.textSecondary,
      opacity: 0.6,
    },
    continueButtonText: {
      color: '#ffffff',
      fontSize: 18,
      fontWeight: 'bold',
    },
    skipButton: {
      padding: 10,
    },
    skipButtonText: {
      color: theme.textSecondary,
      fontSize: 14,
    },
  });

  return (
    <KeyboardAvoidingView 
      style={styles.container} 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.welcomeIcon}>
        <MaterialIcons name="favorite" size={80} color={theme.primary} />
      </View>
      
      <Text style={styles.title}>Bem-vindo!</Text>
      <Text style={styles.subtitle}>Você não está sozinho, viva com propósito</Text>
      <Text style={styles.description}>
        Como podemos te chamar? Seu nome será usado para personalizar sua experiência de fé.
      </Text>

      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Seu nome:</Text>
        <TextInput
          style={styles.input}
          value={name}
          onChangeText={setName}
          placeholder="Digite seu nome aqui..."
          placeholderTextColor={theme.textSecondary}
          maxLength={50}
          returnKeyType="done"
          onSubmitEditing={handleContinue}
        />
      </View>

      <TouchableOpacity
        style={[
          styles.continueButton,
          (!name.trim() || isLoading) && styles.continueButtonDisabled
        ]}
        onPress={handleContinue}
        disabled={!name.trim() || isLoading}
      >
        <Text style={styles.continueButtonText}>
          {isLoading ? 'Salvando...' : 'Continuar'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.skipButton}
        onPress={() => onComplete()}
      >
        <Text style={styles.skipButtonText}>Pular por agora</Text>
      </TouchableOpacity>
    </KeyboardAvoidingView>
  );
}