import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import verses from '../data/verses.json';
import devotionals from '../data/devotionals.json';

// Configurar o comportamento das notificações
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

// Lista de perguntas inteligentes para notificações
const intelligentQuestions = [
  {
    id: 1,
    question: "Como você está se sentindo hoje?",
    responses: {
      alegre: "joy",
      triste: "sadness", 
      ansioso: "anxiety",
      preocupado: "worry",
      grato: "gratitude"
    }
  },
  {
    id: 2,
    question: "O que mais tem ocupado seus pensamentos ultimamente?",
    responses: {
      familia: "family",
      trabalho: "work",
      futuro: "future",
      saude: "health",
      relacionamentos: "relationships"
    }
  },
  {
    id: 3,
    question: "Qual é o seu maior desafio neste momento?",
    responses: {
      financeiro: "financial",
      emocional: "emotional",
      espiritual: "spiritual",
      relacionamento: "relationships",
      saude: "health"
    }
  },
  {
    id: 4,
    question: "O que você gostaria de agradecer a Deus hoje?",
    responses: {
      vida: "gratitude",
      familia: "family",
      saude: "health",
      trabalho: "work",
      paz: "peace"
    }
  },
  {
    id: 5,
    question: "Como podemos orar por você hoje?",
    responses: {
      paz: "peace",
      sabedoria: "wisdom",
      forca: "strength",
      cura: "healing",
      orientacao: "guidance"
    }
  }
];

export const notificationService = {
  // Solicitar permissões para notificações
  async requestPermissions() {
    if (Device.isDevice) {
      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;
      
      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }
      
      if (finalStatus !== 'granted') {
        console.log('Permissão para notificações não concedida');
        return false;
      }
      
      return true;
    } else {
      console.log('Deve usar um dispositivo físico para notificações push');
      return false;
    }
  },

  // Agendar notificação diária com versículo
  async scheduleDailyVerse() {
    try {
      // Não cancelar todas - apenas as diárias se necessário
      
      const today = new Date();
      const dayOfYear = Math.floor((today - new Date(today.getFullYear(), 0, 0)) / 1000 / 60 / 60 / 24);
      const verseIndex = dayOfYear % verses.length;
      const dailyVerse = verses[verseIndex];

      const notificationId = await Notifications.scheduleNotificationAsync({
        content: {
          title: 'Versículo do Dia',
          body: `"${dailyVerse.text}" - ${dailyVerse.reference}`,
          data: { type: 'daily-verse', verse: dailyVerse },
        },
        trigger: {
          hour: 8,
          minute: 0,
          repeats: true,
        },
      });

      console.log('Notificação diária do versículo agendada:', notificationId);
      return notificationId;
    } catch (error) {
      console.error('Erro ao agendar notificação diária:', error);
      return null;
    }
  },

  // Agendar perguntas inteligentes
  async scheduleIntelligentQuestions() {
    try {
      // Agendar para terça, quinta e sábado às 19h
      const daysOfWeek = [2, 4, 6]; // terça=2, quinta=4, sábado=6
      const notificationIds = [];
      
      for (const dayOfWeek of daysOfWeek) {
        const questionIndex = Math.floor(Math.random() * intelligentQuestions.length);
        const question = intelligentQuestions[questionIndex];

        const notificationId = await Notifications.scheduleNotificationAsync({
          content: {
            title: 'Como você está?',
            body: question.question,
            data: { 
              type: 'intelligent-question', 
              questionId: question.id,
              question: question.question 
            },
          },
          trigger: {
            weekday: dayOfWeek,
            hour: 19,
            minute: 0,
            repeats: true,
          },
        });
        
        notificationIds.push(notificationId);
      }

      console.log('Perguntas inteligentes agendadas:', notificationIds);
      return notificationIds;
    } catch (error) {
      console.error('Erro ao agendar perguntas inteligentes:', error);
      return [];
    }
  },

  // Inicializar serviço de notificações
  async initialize() {
    const hasPermission = await this.requestPermissions();
    
    if (hasPermission) {
      // Agendar notificações em sequência para evitar conflitos
      const dailyVerseId = await this.scheduleDailyVerse();
      const questionIds = await this.scheduleIntelligentQuestions();
      
      console.log('Sistema de notificações inicializado com sucesso');
      console.log('ID versículo diário:', dailyVerseId);
      console.log('IDs perguntas inteligentes:', questionIds);
    } else {
      console.log('Permissões de notificação negadas');
    }
    
    return hasPermission;
  },

  // Cancelar todas as notificações
  async cancelAllNotifications() {
    await Notifications.cancelAllScheduledNotificationsAsync();
    console.log('Todas as notificações canceladas');
  },

  // Enviar notificação imediata (para testes)
  async sendTestNotification() {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Teste do App Cristão',
        body: 'Você não está sozinho, viva com propósito! 🙏',
        data: { type: 'test' },
      },
      trigger: { seconds: 1 },
    });
  },

  // Obter versículo baseado no humor/resposta
  getVerseByMood(mood) {
    // Mapear humor para categorias de versículos
    const moodToCategory = {
      joy: "alegria",
      sadness: "conforto", 
      anxiety: "paz",
      worry: "confiança",
      gratitude: "gratidão",
      family: "família",
      work: "trabalho",
      future: "esperança",
      health: "cura",
      relationships: "amor",
      financial: "provisão",
      emotional: "conforto",
      spiritual: "fé",
      peace: "paz",
      wisdom: "sabedoria",
      strength: "força",
      healing: "cura",
      guidance: "orientação"
    };

    const category = moodToCategory[mood] || "conforto";
    
    // Filtrar versículos por categoria (você pode expandir isso)
    const categoryVerses = verses.filter(verse => 
      verse.tags && verse.tags.includes(category)
    );

    if (categoryVerses.length > 0) {
      const randomIndex = Math.floor(Math.random() * categoryVerses.length);
      return categoryVerses[randomIndex];
    }

    // Fallback para versículo aleatório
    const randomIndex = Math.floor(Math.random() * verses.length);
    return verses[randomIndex];
  }
};

export { intelligentQuestions };