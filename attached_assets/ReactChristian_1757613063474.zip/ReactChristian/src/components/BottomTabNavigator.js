import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useTheme } from '../contexts/ThemeContext';
import { MaterialIcons } from '@expo/vector-icons';

// Screens
import HomeScreen from '../screens/HomeScreen';
import BibleScreen from '../screens/BibleScreen';
import HymnsScreen from '../screens/HymnsScreen';
import StoreScreen from '../screens/StoreScreen';
import SettingsScreen from '../screens/SettingsScreen';

const Tab = createBottomTabNavigator();

export default function BottomTabNavigator() {
  const { theme, isDarkMode } = useTheme();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'Início') {
            iconName = 'home';
          } else if (route.name === 'Bíblia') {
            iconName = 'book';
          } else if (route.name === 'Hinário') {
            iconName = 'music-note';
          } else if (route.name === 'Loja') {
            iconName = 'store';
          } else if (route.name === 'Configurações') {
            iconName = 'settings';
          }

          return <MaterialIcons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: theme.primary,
        tabBarInactiveTintColor: theme.textSecondary,
        tabBarStyle: {
          backgroundColor: theme.card,
          borderTopColor: theme.border,
          paddingBottom: 5,
          paddingTop: 5,
          height: 65,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: '500',
        },
        headerStyle: {
          backgroundColor: theme.background,
          shadowColor: 'transparent',
          elevation: 0,
        },
        headerTintColor: theme.text,
        headerTitleStyle: {
          fontWeight: 'bold',
          fontSize: 18,
        },
      })}
    >
      <Tab.Screen 
        name="Início" 
        component={HomeScreen}
        options={{ headerTitle: 'Você não está sozinho' }}
      />
      <Tab.Screen 
        name="Bíblia" 
        component={BibleScreen}
        options={{ headerTitle: 'Bíblia Sagrada' }}
      />
      <Tab.Screen 
        name="Hinário" 
        component={HymnsScreen}
        options={{ headerTitle: 'Harpa Cristã' }}
      />
      <Tab.Screen 
        name="Loja" 
        component={StoreScreen}
        options={{ headerTitle: 'Nossa Loja' }}
      />
      <Tab.Screen 
        name="Configurações" 
        component={SettingsScreen}
        options={{ headerTitle: 'Configurações' }}
      />
    </Tab.Navigator>
  );
}