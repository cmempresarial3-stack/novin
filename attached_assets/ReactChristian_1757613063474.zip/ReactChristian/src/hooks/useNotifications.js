import { useEffect, useRef } from 'react';
import * as Notifications from 'expo-notifications';
import { notificationService } from '../utils/notifications';

export const useNotifications = () => {
  const notificationListener = useRef();
  const responseListener = useRef();

  useEffect(() => {
    // Listener para notificações recebidas
    notificationListener.current = Notifications.addNotificationReceivedListener(notification => {
      console.log('Notificação recebida:', notification);
    });

    // Listener para quando o usuário toca na notificação
    responseListener.current = Notifications.addNotificationResponseReceivedListener(response => {
      const data = response.notification.request.content.data;
      
      if (data.type === 'intelligent-question') {
        // Navegar para tela de resposta da pergunta
        handleIntelligentQuestion(data);
      } else if (data.type === 'daily-verse') {
        // Navegar para tela inicial com versículo
        console.log('Abrir versículo do dia');
      }
    });

    return () => {
      Notifications.removeNotificationSubscription(notificationListener.current);
      Notifications.removeNotificationSubscription(responseListener.current);
    };
  }, []);

  const handleIntelligentQuestion = (data) => {
    // Aqui você pode implementar navegação para uma tela de resposta
    // ou mostrar um modal com opções de resposta
    console.log('Pergunta inteligente:', data.question);
  };

  const sendTestNotification = async () => {
    await notificationService.sendTestNotification();
  };

  return {
    sendTestNotification,
  };
};