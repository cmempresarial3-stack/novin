import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User preferences and data (stored locally in frontend)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Bible verses
export const verses = pgTable("verses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  reference: text("reference").notNull(), // e.g. "João 3:16"
  text: text("text").notNull(),
  book: text("book").notNull(),
  chapter: text("chapter").notNull(),
  verse: text("verse").notNull(),
  category: text("category"), // hope, peace, strength, etc.
});

// Daily devotionals
export const devotionals = pgTable("devotionals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  verseReference: text("verse_reference").notNull(),
  content: text("content").notNull(), // 3-5 paragraphs
  prayer: text("prayer").notNull(),
  date: timestamp("date").notNull(),
});

// Bible books and chapters
export const bibleBooks = pgTable("bible_books", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  testament: text("testament").notNull(), // "old" or "new"
  chapters: jsonb("chapters").notNull(), // array of chapter content
});

// Harpa Cristã hymns
export const hymns = pgTable("hymns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  number: text("number").notNull(),
  title: text("title").notNull(),
  lyrics: jsonb("lyrics").notNull(), // verses and chorus
  audioUrl: text("audio_url"), // optional instrumental track
});

// Notes (stored locally in frontend)
export const notes = pgTable("notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Schemas for validation
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertVerseSchema = createInsertSchema(verses).omit({
  id: true,
});

export const insertDevotionalSchema = createInsertSchema(devotionals).omit({
  id: true,
});

export const insertBibleBookSchema = createInsertSchema(bibleBooks).omit({
  id: true,
});

export const insertHymnSchema = createInsertSchema(hymns).omit({
  id: true,
});

export const insertNoteSchema = createInsertSchema(notes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertVerse = z.infer<typeof insertVerseSchema>;
export type Verse = typeof verses.$inferSelect;

export type InsertDevotional = z.infer<typeof insertDevotionalSchema>;
export type Devotional = typeof devotionals.$inferSelect;

export type InsertBibleBook = z.infer<typeof insertBibleBookSchema>;
export type BibleBook = typeof bibleBooks.$inferSelect;

export type InsertHymn = z.infer<typeof insertHymnSchema>;
export type Hymn = typeof hymns.$inferSelect;

export type InsertNote = z.infer<typeof insertNoteSchema>;
export type Note = typeof notes.$inferSelect;

// Frontend-only types for local storage
export interface UserPreferences {
  userName: string;
  notifications: {
    dailyVerse: boolean;
    prayerReminders: boolean;
    morningPrayer: string;
    eveningPrayer: string;
  };
  currentDeviceId: string;
}

export interface MoodEntry {
  mood: 'peaceful' | 'anxious' | 'grateful' | 'struggling';
  timestamp: string;
  verseId?: string;
}
