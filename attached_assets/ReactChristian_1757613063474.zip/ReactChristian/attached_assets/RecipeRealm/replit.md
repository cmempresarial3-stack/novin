# Overview

This is a Christian mobile application built as a React + Express fullstack web app, designed to provide spiritual comfort and guidance with the core message "Você não está sozinho, viva com propósito" (You are not alone, live with purpose). The app features daily Bible verses, devotionals, a complete Bible reader with TTS functionality, hymn player, personal notes, and background music for prayer and meditation.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client uses a modern React setup with TypeScript, utilizing:
- **Vite** for build tooling and development server
- **Wouter** for client-side routing instead of React Router
- **TanStack Query** for API state management and caching
- **shadcn/ui + Radix UI** components for consistent UI design
- **Tailwind CSS** for styling with a custom design system featuring light blue, gold, and white color palette
- **Local Storage** for user preferences, notes, and offline functionality

The app is structured as a mobile-first progressive web app with a bottom navigation pattern and uses a mobile container design approach.

## Backend Architecture
The server follows a simple Express.js REST API pattern:
- **Express.js** with TypeScript for the HTTP server
- **In-memory storage** implementation for development (designed to be easily replaceable with database)
- **Static file serving** integrated with Vite development server
- **RESTful API endpoints** for verses, devotionals, Bible content, hymns, and background music

## Data Storage Solutions
Currently implements a memory-based storage system with interfaces designed for future database integration:
- **Local Storage (Frontend)**: User preferences, notes, mood entries, and personal data
- **Memory Storage (Backend)**: Bible verses, devotionals, Bible books, hymns, and background music
- **PostgreSQL Ready**: Drizzle ORM configuration and schema already defined for future cloud deployment
- **JSON Data Files**: Static content loaded from server/data/ directory

## Key Features Implementation
- **Daily Verse Algorithm**: Device-based deterministic selection ensuring users get the same verse per day
- **Text-to-Speech**: Native browser TTS integration for Bible chapter narration
- **Background Music Player**: Audio playback system with volume controls
- **Mood Tracking**: Local mood entries that trigger contextual Bible verses
- **Offline-First**: Core functionality works without internet connection

## Authentication and Authorization
The app uses a **local-first approach** with no traditional authentication:
- User data stored locally on device using localStorage
- Device ID generation for verse personalization
- No server-side user accounts or sessions
- Privacy-focused design with minimal data collection

# External Dependencies

## Frontend Dependencies
- **React 18** with TypeScript for UI framework
- **Vite** for build system and development
- **TanStack Query** for server state management
- **Wouter** for client-side routing
- **shadcn/ui components** built on Radix UI primitives
- **Tailwind CSS** for utility-first styling
- **Lucide React** for consistent iconography

## Backend Dependencies
- **Express.js** for HTTP server
- **Drizzle ORM** with PostgreSQL dialect for future database integration
- **Neon Database** serverless PostgreSQL (configured but not yet implemented)
- **tsx** for TypeScript execution in development

## Development Tools
- **ESBuild** for production server bundling
- **PostCSS + Autoprefixer** for CSS processing
- **TypeScript** with strict configuration
- **Replit integration** for cloud development environment

## Content Sources
- **Almeida Corrigida Fiel (ACF) Bible**: Public domain Portuguese Bible translation
- **Harpa Cristã**: Traditional Christian hymnal (public domain)
- **Royalty-free instrumental music** for background audio
- **Custom devotional content** integrated with daily verses

The application is designed to be easily deployable to various platforms while maintaining its offline-first, privacy-focused approach to Christian spiritual guidance.