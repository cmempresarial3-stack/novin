import { type Verse, type Devotional, type BibleBook, type Hymn, type Note, type InsertVerse, type InsertDevotional, type InsertBibleBook, type InsertHymn, type InsertNote } from "@shared/schema";
import { randomUUID } from "crypto";
import fs from "fs";
import path from "path";

export interface IStorage {
  // Verses
  getVerse(id: string): Promise<Verse | undefined>;
  getVerseByDay(deviceId: string, date: string): Promise<Verse | undefined>;
  getVersesByCategory(category: string): Promise<Verse[]>;
  getAllVerses(): Promise<Verse[]>;
  
  // Devotionals
  getDevotional(id: string): Promise<Devotional | undefined>;
  getDevotionalByDate(date: string): Promise<Devotional | undefined>;
  getAllDevotionals(): Promise<Devotional[]>;
  
  // Bible
  getBibleBook(name: string): Promise<BibleBook | undefined>;
  getAllBibleBooks(): Promise<BibleBook[]>;
  
  // Hymns
  getHymn(id: string): Promise<Hymn | undefined>;
  getHymnByNumber(number: string): Promise<Hymn | undefined>;
  getAllHymns(): Promise<Hymn[]>;
  
  // Notes (for future cloud sync)
  getNote(id: string): Promise<Note | undefined>;
  createNote(note: InsertNote): Promise<Note>;
  updateNote(id: string, note: Partial<Note>): Promise<Note | undefined>;
  deleteNote(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private verses: Map<string, Verse>;
  private devotionals: Map<string, Devotional>;
  private bibleBooks: Map<string, BibleBook>;
  private hymns: Map<string, Hymn>;
  private notes: Map<string, Note>;

  constructor() {
    this.verses = new Map();
    this.devotionals = new Map();
    this.bibleBooks = new Map();
    this.hymns = new Map();
    this.notes = new Map();
    this.loadData();
  }

  private async loadData() {
    try {
      // Load verses
      const versesData = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'server/data/verses.json'), 'utf8'));
      versesData.forEach((verse: Verse) => {
        this.verses.set(verse.id, verse);
      });

      // Load devotionals
      const devotionalsData = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'server/data/devotionals.json'), 'utf8'));
      devotionalsData.forEach((devotional: Devotional) => {
        this.devotionals.set(devotional.id, devotional);
      });

      // Load Bible books
      const bibleData = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'server/data/bible-acf.json'), 'utf8'));
      bibleData.forEach((book: BibleBook) => {
        this.bibleBooks.set(book.name, book);
      });

      // Load hymns
      const hymnsData = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'server/data/harpa-crista.json'), 'utf8'));
      hymnsData.forEach((hymn: Hymn) => {
        this.hymns.set(hymn.id, hymn);
      });
    } catch (error) {
      console.warn('Some data files not found, continuing with empty storage');
    }
  }

  // Verses
  async getVerse(id: string): Promise<Verse | undefined> {
    return this.verses.get(id);
  }

  async getVerseByDay(deviceId: string, date: string): Promise<Verse | undefined> {
    // Simple algorithm: use device ID and date to generate consistent verse
    const verses = Array.from(this.verses.values());
    if (verses.length === 0) return undefined;
    
    const hash = this.hashString(deviceId + date);
    const index = hash % verses.length;
    return verses[index];
  }

  async getVersesByCategory(category: string): Promise<Verse[]> {
    return Array.from(this.verses.values()).filter(verse => verse.category === category);
  }

  async getAllVerses(): Promise<Verse[]> {
    return Array.from(this.verses.values());
  }

  // Devotionals
  async getDevotional(id: string): Promise<Devotional | undefined> {
    return this.devotionals.get(id);
  }

  async getDevotionalByDate(date: string): Promise<Devotional | undefined> {
    const devotionals = Array.from(this.devotionals.values());
    if (devotionals.length === 0) return undefined;
    
    // Use date to get consistent devotional
    const hash = this.hashString(date);
    const index = hash % devotionals.length;
    return devotionals[index];
  }

  async getAllDevotionals(): Promise<Devotional[]> {
    return Array.from(this.devotionals.values());
  }

  // Bible
  async getBibleBook(name: string): Promise<BibleBook | undefined> {
    return this.bibleBooks.get(name);
  }

  async getAllBibleBooks(): Promise<BibleBook[]> {
    return Array.from(this.bibleBooks.values());
  }

  // Hymns
  async getHymn(id: string): Promise<Hymn | undefined> {
    return this.hymns.get(id);
  }

  async getHymnByNumber(number: string): Promise<Hymn | undefined> {
    return Array.from(this.hymns.values()).find(hymn => hymn.number === number);
  }

  async getAllHymns(): Promise<Hymn[]> {
    return Array.from(this.hymns.values());
  }

  // Notes
  async getNote(id: string): Promise<Note | undefined> {
    return this.notes.get(id);
  }

  async createNote(insertNote: InsertNote): Promise<Note> {
    const id = randomUUID();
    const note: Note = {
      ...insertNote,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.notes.set(id, note);
    return note;
  }

  async updateNote(id: string, updateData: Partial<Note>): Promise<Note | undefined> {
    const note = this.notes.get(id);
    if (!note) return undefined;
    
    const updatedNote = { ...note, ...updateData, updatedAt: new Date() };
    this.notes.set(id, updatedNote);
    return updatedNote;
  }

  async deleteNote(id: string): Promise<boolean> {
    return this.notes.delete(id);
  }

  // Utility
  private hashString(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash);
  }
}

export const storage = new MemStorage();
