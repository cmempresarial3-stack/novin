import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Verses API
  app.get("/api/verses", async (req, res) => {
    try {
      const verses = await storage.getAllVerses();
      res.json(verses);
    } catch (error) {
      res.status(500).json({ message: "Error fetching verses" });
    }
  });

  app.get("/api/verses/daily", async (req, res) => {
    try {
      const { deviceId } = req.query;
      const today = new Date().toISOString().split('T')[0];
      const verse = await storage.getVerseByDay(deviceId as string, today);
      res.json(verse);
    } catch (error) {
      res.status(500).json({ message: "Error fetching daily verse" });
    }
  });

  app.get("/api/verses/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const verses = await storage.getVersesByCategory(category);
      res.json(verses);
    } catch (error) {
      res.status(500).json({ message: "Error fetching verses by category" });
    }
  });

  // Devotionals API
  app.get("/api/devotionals", async (req, res) => {
    try {
      const devotionals = await storage.getAllDevotionals();
      res.json(devotionals);
    } catch (error) {
      res.status(500).json({ message: "Error fetching devotionals" });
    }
  });

  app.get("/api/devotionals/daily", async (req, res) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const devotional = await storage.getDevotionalByDate(today);
      res.json(devotional);
    } catch (error) {
      res.status(500).json({ message: "Error fetching daily devotional" });
    }
  });

  // Bible API
  app.get("/api/bible/books", async (req, res) => {
    try {
      const books = await storage.getAllBibleBooks();
      res.json(books);
    } catch (error) {
      res.status(500).json({ message: "Error fetching Bible books" });
    }
  });

  app.get("/api/bible/books/:name", async (req, res) => {
    try {
      const { name } = req.params;
      const book = await storage.getBibleBook(name);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      res.json(book);
    } catch (error) {
      res.status(500).json({ message: "Error fetching Bible book" });
    }
  });

  // Hymns API
  app.get("/api/hymns", async (req, res) => {
    try {
      const hymns = await storage.getAllHymns();
      res.json(hymns);
    } catch (error) {
      res.status(500).json({ message: "Error fetching hymns" });
    }
  });

  app.get("/api/hymns/:number", async (req, res) => {
    try {
      const { number } = req.params;
      const hymn = await storage.getHymnByNumber(number);
      if (!hymn) {
        return res.status(404).json({ message: "Hymn not found" });
      }
      res.json(hymn);
    } catch (error) {
      res.status(500).json({ message: "Error fetching hymn" });
    }
  });

  // Background music API
  app.get("/api/background-music", async (req, res) => {
    try {
      // Return list of available background music tracks
      // Using working audio test files for demonstration
      const musicList = [
        { id: "peaceful1", name: "Peaceful Piano", url: "https://file-examples.com/storage/feb7c5f0d8e7de9b8e3c5a0/2017/11/file_example_MP3_700KB.mp3" },
        { id: "worship1", name: "Soft Worship", url: "https://www.learningcontainer.com/wp-content/uploads/2020/02/Kalimba.mp3" },
        { id: "meditation1", name: "Meditation Strings", url: "https://samplelib.com/lib/preview/mp3/sample-3s.mp3" }
      ];
      res.json(musicList);
    } catch (error) {
      res.status(500).json({ message: "Error fetching background music" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
