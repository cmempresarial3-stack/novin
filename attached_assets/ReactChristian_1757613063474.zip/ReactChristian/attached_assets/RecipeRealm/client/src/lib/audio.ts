// Text-to-Speech functionality for Bible reading
export class TTSService {
  private utterance: SpeechSynthesisUtterance | null = null;
  private isReading = false;

  constructor() {
    // Check if TTS is supported
    if (!('speechSynthesis' in window)) {
      console.warn('Text-to-Speech not supported in this browser');
    }
  }

  speak(text: string, options?: { rate?: number; pitch?: number; volume?: number; lang?: string }): void {
    if (!('speechSynthesis' in window)) return;

    // Stop any ongoing speech
    this.stop();

    this.utterance = new SpeechSynthesisUtterance(text);
    this.utterance.rate = options?.rate || 0.8;
    this.utterance.pitch = options?.pitch || 1;
    this.utterance.volume = options?.volume || 1;
    this.utterance.lang = options?.lang || 'pt-BR';

    this.utterance.onstart = () => {
      this.isReading = true;
    };

    this.utterance.onend = () => {
      this.isReading = false;
    };

    this.utterance.onerror = (event) => {
      console.error('Speech synthesis error:', event.error);
      this.isReading = false;
    };

    speechSynthesis.speak(this.utterance);
  }

  stop(): void {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
      this.isReading = false;
    }
  }

  pause(): void {
    if ('speechSynthesis' in window && this.isReading) {
      speechSynthesis.pause();
    }
  }

  resume(): void {
    if ('speechSynthesis' in window) {
      speechSynthesis.resume();
    }
  }

  getIsReading(): boolean {
    return this.isReading;
  }

  // Get available voices
  getVoices(): SpeechSynthesisVoice[] {
    if (!('speechSynthesis' in window)) return [];
    return speechSynthesis.getVoices();
  }

  // Get Portuguese voices specifically
  getPortugueseVoices(): SpeechSynthesisVoice[] {
    return this.getVoices().filter(voice => 
      voice.lang.startsWith('pt') || voice.lang.includes('BR')
    );
  }
}

// Audio player for hymns and background music
export class AudioPlayer {
  private audio: HTMLAudioElement;
  private callbacks: { [key: string]: Function[] } = {};

  constructor() {
    this.audio = new Audio();
    this.setupEventListeners();
  }

  private setupEventListeners(): void {
    this.audio.addEventListener('loadstart', () => this.emit('loadstart'));
    this.audio.addEventListener('loadeddata', () => this.emit('loadeddata'));
    this.audio.addEventListener('canplay', () => this.emit('canplay'));
    this.audio.addEventListener('play', () => this.emit('play'));
    this.audio.addEventListener('pause', () => this.emit('pause'));
    this.audio.addEventListener('ended', () => this.emit('ended'));
    this.audio.addEventListener('timeupdate', () => this.emit('timeupdate'));
    this.audio.addEventListener('error', (e) => this.emit('error', e));
  }

  load(src: string): void {
    this.audio.src = src;
    this.audio.load();
  }

  play(): Promise<void> {
    return this.audio.play();
  }

  pause(): void {
    this.audio.pause();
  }

  stop(): void {
    this.audio.pause();
    this.audio.currentTime = 0;
  }

  setVolume(volume: number): void {
    this.audio.volume = Math.max(0, Math.min(1, volume));
  }

  setCurrentTime(time: number): void {
    this.audio.currentTime = time;
  }

  getCurrentTime(): number {
    return this.audio.currentTime;
  }

  getDuration(): number {
    return this.audio.duration || 0;
  }

  setLoop(loop: boolean): void {
    this.audio.loop = loop;
  }

  getIsPlaying(): boolean {
    return !this.audio.paused;
  }

  // Event system
  on(event: string, callback: Function): void {
    if (!this.callbacks[event]) {
      this.callbacks[event] = [];
    }
    this.callbacks[event].push(callback);
  }

  off(event: string, callback: Function): void {
    if (this.callbacks[event]) {
      this.callbacks[event] = this.callbacks[event].filter(cb => cb !== callback);
    }
  }

  private emit(event: string, data?: any): void {
    if (this.callbacks[event]) {
      this.callbacks[event].forEach(callback => callback(data));
    }
  }

  destroy(): void {
    this.audio.pause();
    this.audio.src = '';
    this.callbacks = {};
  }
}

// Create singleton instances
export const ttsService = new TTSService();
export const audioPlayer = new AudioPlayer();
