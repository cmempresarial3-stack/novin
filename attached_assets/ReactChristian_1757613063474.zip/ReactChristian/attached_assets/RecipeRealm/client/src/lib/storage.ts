import { useState, useEffect } from 'react';

// Custom hook for localStorage with TypeScript support
export function useLocalStorage<T>(key: string, initialValue: T) {
  // Get initial value from localStorage
  const [storedValue, setStoredValue] = useState<T>(() => {
    if (typeof window === "undefined") {
      return initialValue;
    }
    
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.warn(`Error reading localStorage key "${key}":`, error);
      return initialValue;
    }
  });

  // Return a wrapped version of useState's setter function that persists to localStorage
  const setValue = (value: T | ((val: T) => T)) => {
    try {
      // Allow value to be a function so we have the same API as useState
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      
      // Save to localStorage
      if (typeof window !== "undefined") {
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      }
    } catch (error) {
      console.warn(`Error setting localStorage key "${key}":`, error);
    }
  };

  return [storedValue, setValue] as const;
}

// In-memory cache for device ID
let inMemoryDeviceId: string | null = null;

// Helper function to get device ID for verse algorithm - fully resilient to storage failures
export function getDeviceId(): string {
  // Return cached value if available
  if (inMemoryDeviceId) return inMemoryDeviceId;
  
  // Try to read from localStorage safely
  try {
    const stored = window.localStorage.getItem('deviceId');
    if (stored) {
      inMemoryDeviceId = stored;
      return stored;
    }
  } catch {
    // localStorage access blocked - continue with generation
  }
  
  // Generate new device ID
  let newId: string;
  try {
    // Try crypto.randomUUID first
    newId = typeof crypto?.randomUUID === 'function' ? crypto.randomUUID() : '';
  } catch {
    newId = '';
  }
  
  // Fallback ID generation if crypto fails
  if (!newId) {
    newId = 'device-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 11);
  }
  
  // Try to persist to localStorage if possible
  try {
    window.localStorage.setItem('deviceId', newId);
  } catch {
    // localStorage write failed - continue with in-memory only
  }
  
  // Cache in memory regardless of persistence success
  inMemoryDeviceId = newId;
  return newId;
}

// Helper function to clear all app data
export function clearAppData(): void {
  const keysToRemove = [
    'userPreferences',
    'notes',
    'moodEntries',
    'deviceId',
    'favoriteHymns',
    'prayerSchedule'
  ];
  
  keysToRemove.forEach(key => {
    localStorage.removeItem(key);
  });
}
