import type { UserPreferences } from "@shared/schema";

export interface NotificationConfig {
  title: string;
  body: string;
  icon?: string;
  tag?: string;
}

// Request notification permission
export async function requestNotificationPermission(): Promise<boolean> {
  if (!("Notification" in window)) {
    console.warn("This browser does not support notifications");
    return false;
  }

  if (Notification.permission === "granted") {
    return true;
  }

  if (Notification.permission === "denied") {
    return false;
  }

  const permission = await Notification.requestPermission();
  return permission === "granted";
}

// Show notification
export function showNotification(config: NotificationConfig): void {
  if (Notification.permission !== "granted") return;

  const notification = new Notification(config.title, {
    body: config.body,
    icon: config.icon || "/favicon.ico",
    tag: config.tag,
  });

  // Auto close after 5 seconds
  setTimeout(() => notification.close(), 5000);
}

// Schedule daily verse notification
export function scheduleDailyVerseNotification(preferences: UserPreferences): void {
  if (!preferences.notifications.dailyVerse) return;

  // Simple scheduling - in a real app, you'd use service workers
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(8, 0, 0, 0); // 8 AM

  const timeUntilTomorrow = tomorrow.getTime() - now.getTime();

  setTimeout(() => {
    showNotification({
      title: `Bom dia, ${preferences.userName}!`,
      body: "Seu verso diário está disponível. Que Deus abençoe seu dia!",
      tag: "daily-verse",
    });

    // Reschedule for next day
    scheduleDailyVerseNotification(preferences);
  }, timeUntilTomorrow);
}

// Schedule prayer reminders
export function schedulePrayerReminders(preferences: UserPreferences): void {
  if (!preferences.notifications.prayerReminders) return;

  const scheduleTime = (timeString: string, period: 'morning' | 'evening') => {
    const [hours, minutes] = timeString.split(':').map(Number);
    const now = new Date();
    const scheduledTime = new Date();
    scheduledTime.setHours(hours, minutes, 0, 0);

    if (scheduledTime <= now) {
      scheduledTime.setDate(scheduledTime.getDate() + 1);
    }

    const timeUntilScheduled = scheduledTime.getTime() - now.getTime();

    setTimeout(() => {
      const periodText = period === 'morning' ? 'manhã' : 'noite';
      showNotification({
        title: `${preferences.userName}, hora da oração da ${periodText}`,
        body: "Dedique alguns minutos para conversar com Deus",
        tag: `prayer-${period}`,
      });

      // Reschedule for next day
      schedulePrayerReminders(preferences);
    }, timeUntilScheduled);
  };

  scheduleTime(preferences.notifications.morningPrayer, 'morning');
  scheduleTime(preferences.notifications.eveningPrayer, 'evening');
}

// Initialize notification system
export async function initializeNotifications(preferences: UserPreferences): Promise<void> {
  const hasPermission = await requestNotificationPermission();
  
  if (hasPermission) {
    scheduleDailyVerseNotification(preferences);
    schedulePrayerReminders(preferences);
  }
}
