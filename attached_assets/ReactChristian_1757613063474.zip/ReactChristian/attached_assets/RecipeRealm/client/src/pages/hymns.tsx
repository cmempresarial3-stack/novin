import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Search, Play, Pause, Heart, Share, ChevronLeft, ChevronRight, List } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Hymn } from "@shared/schema";

export default function HymnsPage() {
  const [, setLocation] = useLocation();
  const [currentHymnNumber, setCurrentHymnNumber] = useState("149");
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showList, setShowList] = useState(true);
  const audioRef = useRef<HTMLAudioElement>(null);
  const { toast } = useToast();

  const { data: hymns, isLoading: hymnsLoading } = useQuery<Hymn[]>({
    queryKey: ['/api/hymns'],
  });

  const { data: currentHymn, isLoading: hymnLoading } = useQuery<Hymn>({
    queryKey: ['/api/hymns', currentHymnNumber],
    enabled: !!currentHymnNumber,
  });

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const updateDuration = () => setDuration(audio.duration);

    audio.addEventListener('timeupdate', updateTime);
    audio.addEventListener('loadedmetadata', updateDuration);
    audio.addEventListener('ended', () => setIsPlaying(false));

    return () => {
      audio.removeEventListener('timeupdate', updateTime);
      audio.removeEventListener('loadedmetadata', updateDuration);
      audio.removeEventListener('ended', () => setIsPlaying(false));
    };
  }, [currentHymn]);

  const togglePlayPause = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
    } else {
      audio.play();
    }
    setIsPlaying(!isPlaying);
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleShare = async () => {
    if (!currentHymn) return;
    
    try {
      await navigator.share({
        title: `${currentHymn.title} - Harpa Cristã ${currentHymn.number}`,
        text: `Confira este lindo hino: ${currentHymn.title}`,
        url: window.location.href,
      });
    } catch {
      navigator.clipboard.writeText(`${currentHymn.title} - Harpa Cristã ${currentHymn.number}`);
      toast({
        title: "Copiado!",
        description: "Hino copiado para a área de transferência",
      });
    }
  };

  const handleFavorite = () => {
    toast({
      title: "Favoritado!",
      description: "Hino adicionado aos seus favoritos",
    });
  };

  const navigateHymn = (direction: 'prev' | 'next') => {
    if (!hymns) return;
    
    const currentIndex = hymns.findIndex(hymn => hymn.number === currentHymnNumber);
    if (currentIndex === -1) return;
    
    if (direction === 'prev' && currentIndex > 0) {
      setCurrentHymnNumber(hymns[currentIndex - 1].number);
    } else if (direction === 'next' && currentIndex < hymns.length - 1) {
      setCurrentHymnNumber(hymns[currentIndex + 1].number);
    }
  };

  return (
    <div className="min-h-screen pb-20">
      <div className="bg-gradient-to-br from-secondary/10 to-primary/10">
        <div className="px-6 py-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Button
                variant="ghost"
                size="icon"
                className="mr-4 p-2 hover:bg-white/50 rounded-full tab-transition"
                onClick={() => setLocation('/home')}
                data-testid="button-back"
              >
                <ArrowLeft className="text-foreground" size={20} />
              </Button>
              <h1 className="text-xl font-semibold text-foreground">Harpa Cristã</h1>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="p-2 bg-white rounded-full soft-shadow"
              data-testid="button-search-hymns"
            >
              <Search className="text-muted-foreground" size={16} />
            </Button>
          </div>
          
          {/* Hymn List */}
          {showList ? (
            <Card className="card-shadow mb-4">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <h2 className="text-xl font-bold text-foreground">Harpa Cristã</h2>
                  <p className="text-sm text-muted-foreground">Selecione um hino</p>
                </div>
                
                {hymnsLoading ? (
                  <div className="space-y-2">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="h-12 bg-muted rounded animate-pulse"></div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {hymns?.map((hymn) => (
                      <Button
                        key={hymn.number}
                        variant="outline"
                        className="w-full justify-start h-auto py-3 text-left"
                        onClick={() => {
                          setCurrentHymnNumber(hymn.number);
                          setShowList(false);
                        }}
                        data-testid={`hymn-list-item-${hymn.number}`}
                      >
                        <div>
                          <p className="font-medium">{hymn.number}. {hymn.title}</p>
                          <p className="text-sm text-muted-foreground">Harpa Cristã</p>
                        </div>
                      </Button>
                    ))}
                  </div>
                )}
                
                <Button
                  className="w-full mt-4"
                  onClick={() => setShowList(false)}
                  data-testid="button-back-to-hymn"
                >
                  Voltar ao Hino Atual
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Current Hymn */}
              {hymnLoading ? (
            <Card className="card-shadow">
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-6 bg-muted rounded w-3/4 mx-auto"></div>
                  <div className="h-4 bg-muted rounded w-1/2 mx-auto"></div>
                  <div className="h-20 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ) : currentHymn ? (
            <Card className="card-shadow mb-4">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold text-foreground mb-1" data-testid="text-hymn-title">
                    {currentHymn.title}
                  </h2>
                  <p className="text-sm text-muted-foreground">Harpa Cristã - Hino {currentHymn.number}</p>
                </div>
                
                {/* Audio Player */}
                {currentHymn.audioUrl && (
                  <div className="bg-muted rounded-lg p-4 mb-6">
                    <audio ref={audioRef} src={currentHymn.audioUrl} />
                    <div className="flex items-center justify-between mb-3">
                      <Button
                        size="lg"
                        className="p-3 bg-primary text-primary-foreground rounded-full"
                        onClick={togglePlayPause}
                        data-testid="button-play-hymn"
                      >
                        {isPlaying ? <Pause size={20} /> : <Play size={20} />}
                      </Button>
                      <div className="flex-1 mx-4">
                        <div className="h-1 bg-border rounded-full">
                          <div 
                            className="h-1 bg-primary rounded-full transition-all"
                            style={{ width: duration ? `${(currentTime / duration) * 100}%` : '0%' }}
                          ></div>
                        </div>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {formatTime(currentTime)} / {formatTime(duration)}
                      </span>
                    </div>
                  </div>
                )}
                
                {/* Lyrics */}
                <div className="space-y-4 text-foreground leading-relaxed">
                  {(currentHymn.lyrics as {verses?: Array<{title: string, content: string}>, chorus?: string}).verses?.map((verse, index: number) => (
                    <div key={index} className="mb-4">
                      <p className="serif text-lg font-medium mb-2">{verse.title}:</p>
                      <p className="serif text-base whitespace-pre-line">{verse.content}</p>
                    </div>
                  ))}
                  
                  {(currentHymn.lyrics as {verses?: Array<{title: string, content: string}>, chorus?: string}).chorus && (
                    <div className="bg-accent/50 p-4 rounded-lg">
                      <p className="serif text-lg font-medium mb-2">Coro:</p>
                      <p className="serif text-base whitespace-pre-line">{(currentHymn.lyrics as {verses?: Array<{title: string, content: string}>, chorus?: string}).chorus}</p>
                    </div>
                  )}
                </div>
                
                <div className="flex gap-3 mt-6">
                  <Button
                    className="flex-1 bg-secondary text-secondary-foreground"
                    onClick={handleShare}
                    data-testid="button-share-hymn"
                  >
                    <Share className="mr-2" size={16} />
                    Compartilhar
                  </Button>
                  <Button
                    className="flex-1 bg-primary text-primary-foreground"
                    onClick={handleFavorite}
                    data-testid="button-favorite-hymn"
                  >
                    <Heart className="mr-2" size={16} />
                    Favoritar
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-muted-foreground">Hino não encontrado</p>
              </CardContent>
            </Card>
          )}
          </>
        )}
          
          {/* Hymn Navigation */}
          {!showList && (
          <div className="flex gap-2">
            <Button
              variant="outline"
              className="flex-1 bg-white soft-shadow"
              onClick={() => navigateHymn('prev')}
              data-testid="button-previous-hymn"
            >
              <ChevronLeft className="mr-2" size={16} />
              Anterior
            </Button>
            <Button
              variant="outline"
              className="flex-1 bg-white soft-shadow"
              onClick={() => setShowList(true)}
              data-testid="button-hymn-list"
            >
              <List className="mr-2" size={16} />
              Lista de Hinos
            </Button>
            <Button
              variant="outline"
              className="flex-1 bg-white soft-shadow"
              onClick={() => navigateHymn('next')}
              data-testid="button-next-hymn"
            >
              Próximo
              <ChevronRight className="ml-2" size={16} />
            </Button>
          </div>
          )}
        </div>
      </div>
    </div>
  );
}
