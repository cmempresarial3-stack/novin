import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Bell, ShoppingBag, Share, Info, User, ChevronRight } from "lucide-react";
import { useLocalStorage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import type { UserPreferences } from "@shared/schema";

export default function SettingsPage() {
  const [, setLocation] = useLocation();
  const [userPreferences, setUserPreferences] = useLocalStorage<UserPreferences>('userPreferences', null);
  const { toast } = useToast();

  const handleNotificationChange = (setting: keyof UserPreferences['notifications'], value: boolean | string) => {
    if (!userPreferences) return;

    const updatedPreferences = {
      ...userPreferences,
      notifications: {
        ...userPreferences.notifications,
        [setting]: value,
      },
    };

    setUserPreferences(updatedPreferences);
    toast({
      title: "Configuração salva",
      description: "Suas preferências foram atualizadas.",
    });
  };

  const openStore = () => {
    // Open store in WebView or new tab
    window.open('https://example.com/store', '_blank');
  };

  const openSocial = () => {
    toast({
      title: "Redes Sociais",
      description: "Abrindo links para redes sociais...",
    });
  };

  const showAbout = () => {
    toast({
      title: "Aplicativo Cristão v1.0",
      description: "Desenvolvido com amor para edificar sua fé. Você não está sozinho, viva com propósito.",
    });
  };

  if (!userPreferences) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">Erro ao carregar configurações</p>
            <Button onClick={() => setLocation('/home')} className="mt-4">
              Voltar
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20">
      <div className="px-6 py-8">
        <div className="flex items-center mb-6">
          <Button
            variant="ghost"
            size="icon"
            className="mr-4 p-2 hover:bg-muted rounded-full tab-transition"
            onClick={() => setLocation('/home')}
            data-testid="button-back"
          >
            <ArrowLeft className="text-foreground" size={20} />
          </Button>
          <h1 className="text-xl font-semibold text-foreground">Configurações</h1>
        </div>
        
        {/* Notification Settings */}
        <Card className="card-shadow mb-4">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Notificações</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-foreground">Verso diário</p>
                  <p className="text-sm text-muted-foreground">Receba o verso do dia</p>
                </div>
                <Switch
                  checked={userPreferences.notifications.dailyVerse}
                  onCheckedChange={(checked) => handleNotificationChange('dailyVerse', checked)}
                  data-testid="switch-daily-verse"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-foreground">Lembretes de oração</p>
                  <p className="text-sm text-muted-foreground">Horários personalizados</p>
                </div>
                <Switch
                  checked={userPreferences.notifications.prayerReminders}
                  onCheckedChange={(checked) => handleNotificationChange('prayerReminders', checked)}
                  data-testid="switch-prayer-reminders"
                />
              </div>
              
              {userPreferences.notifications.prayerReminders && (
                <div className="border-t border-border pt-4">
                  <h4 className="font-medium text-foreground mb-3">Horários de Oração</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Manhã</span>
                      <Input
                        type="time"
                        value={userPreferences.notifications.morningPrayer}
                        onChange={(e) => handleNotificationChange('morningPrayer', e.target.value)}
                        className="w-24 text-sm"
                        data-testid="input-morning-prayer"
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Noite</span>
                      <Input
                        type="time"
                        value={userPreferences.notifications.eveningPrayer}
                        onChange={(e) => handleNotificationChange('eveningPrayer', e.target.value)}
                        className="w-24 text-sm"
                        data-testid="input-evening-prayer"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Other Settings */}
        <Card className="card-shadow mb-4">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Outros</h3>
            
            <div className="space-y-4">
              <Button
                variant="ghost"
                className="flex items-center justify-between w-full text-left p-0 h-auto"
                onClick={openStore}
                data-testid="button-open-store"
              >
                <div className="flex items-center">
                  <ShoppingBag className="text-primary mr-3" size={20} />
                  <span className="font-medium text-foreground">Loja</span>
                </div>
                <ChevronRight className="text-muted-foreground" size={16} />
              </Button>
              
              <Button
                variant="ghost"
                className="flex items-center justify-between w-full text-left p-0 h-auto"
                onClick={openSocial}
                data-testid="button-open-social"
              >
                <div className="flex items-center">
                  <Share className="text-primary mr-3" size={20} />
                  <span className="font-medium text-foreground">Redes Sociais</span>
                </div>
                <ChevronRight className="text-muted-foreground" size={16} />
              </Button>
              
              <Button
                variant="ghost"
                className="flex items-center justify-between w-full text-left p-0 h-auto"
                onClick={showAbout}
                data-testid="button-about-app"
              >
                <div className="flex items-center">
                  <Info className="text-primary mr-3" size={20} />
                  <span className="font-medium text-foreground">Sobre o App</span>
                </div>
                <ChevronRight className="text-muted-foreground" size={16} />
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* User Info */}
        <Card className="card-shadow">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Meu Perfil</h3>
            <div className="flex items-center">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mr-4">
                <User className="text-primary-foreground" size={24} />
              </div>
              <div>
                <p className="font-medium text-foreground" data-testid="text-profile-name">
                  {userPreferences.userName}
                </p>
                <p className="text-sm text-muted-foreground">Dados salvos localmente</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
