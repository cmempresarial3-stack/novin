import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ArrowLeft, Plus, Trash2, Edit } from "lucide-react";
import { useLocalStorage, getDeviceId } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";

interface LocalNote {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}

export default function NotesPage() {
  const [, setLocation] = useLocation();
  const [notes, setNotes] = useLocalStorage<LocalNote[]>('notes', []);
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [editingNote, setEditingNote] = useState<LocalNote | null>(null);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const { toast } = useToast();

  const handleAddNote = () => {
    if (!newTitle.trim() && !newContent.trim()) return;

    const newNote: LocalNote = {
      id: 'note-' + Date.now().toString(36) + '-' + Math.random().toString(36).substr(2, 9),
      title: newTitle.trim() || 'Sem título',
      content: newContent.trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setNotes([newNote, ...notes]);
    setNewTitle('');
    setNewContent('');
    setIsAddingNote(false);
    
    toast({
      title: "Anotação criada!",
      description: "Sua anotação foi salva com sucesso.",
    });
  };

  const handleEditNote = (note: LocalNote) => {
    setEditingNote(note);
    setNewTitle(note.title);
    setNewContent(note.content);
  };

  const handleUpdateNote = () => {
    if (!editingNote) return;

    const updatedNotes = notes.map((note: LocalNote) =>
      note.id === editingNote.id
        ? {
            ...note,
            title: newTitle.trim() || 'Sem título',
            content: newContent.trim(),
            updatedAt: new Date().toISOString(),
          }
        : note
    );

    setNotes(updatedNotes);
    setEditingNote(null);
    setNewTitle('');
    setNewContent('');
    
    toast({
      title: "Anotação atualizada!",
      description: "Suas alterações foram salvas.",
    });
  };

  const handleDeleteNote = (id: string) => {
    setNotes(notes.filter((note: LocalNote) => note.id !== id));
    toast({
      title: "Anotação excluída",
      description: "A anotação foi removida com sucesso.",
    });
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return 'Hoje, ' + date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    if (diffDays === 2) return 'Ontem, ' + date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    if (diffDays < 7) return `${diffDays - 1} dias atrás, ` + date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    
    return date.toLocaleDateString('pt-BR') + ', ' + date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen pb-20">
      <div className="px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              className="mr-4 p-2 hover:bg-muted rounded-full tab-transition"
              onClick={() => setLocation('/home')}
              data-testid="button-back"
            >
              <ArrowLeft className="text-foreground" size={20} />
            </Button>
            <h1 className="text-xl font-semibold text-foreground">Minhas Anotações</h1>
          </div>
          
          <Dialog open={isAddingNote} onOpenChange={setIsAddingNote}>
            <DialogTrigger asChild>
              <Button
                className="bg-primary text-primary-foreground p-2 rounded-full"
                data-testid="button-add-note"
              >
                <Plus size={20} />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Nova Anotação</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Input
                  placeholder="Título da anotação"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  data-testid="input-note-title"
                />
                <Textarea
                  placeholder="Escreva sua anotação aqui..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  rows={6}
                  data-testid="textarea-note-content"
                />
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsAddingNote(false)}
                    className="flex-1"
                  >
                    Cancelar
                  </Button>
                  <Button
                    onClick={handleAddNote}
                    className="flex-1 bg-primary text-primary-foreground"
                    data-testid="button-save-note"
                  >
                    Salvar
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
        
        {notes.length > 0 ? (
          <div className="space-y-4">
            {notes.map((note: LocalNote) => (
              <Card key={note.id} className="card-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground" data-testid={`text-note-title-${note.id}`}>
                        {note.title}
                      </h3>
                      <p className="text-xs text-muted-foreground">
                        {formatDate(note.createdAt)}
                      </p>
                    </div>
                    <div className="flex gap-1 ml-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-muted-foreground hover:text-foreground h-8 w-8 p-0"
                        onClick={() => handleEditNote(note)}
                        data-testid={`button-edit-note-${note.id}`}
                      >
                        <Edit size={14} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-muted-foreground hover:text-destructive h-8 w-8 p-0"
                        onClick={() => handleDeleteNote(note.id)}
                        data-testid={`button-delete-note-${note.id}`}
                      >
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {note.content.length > 150 
                      ? note.content.substring(0, 150) + '...'
                      : note.content
                    }
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Edit className="text-4xl text-muted-foreground mb-4 mx-auto" size={64} />
            <h3 className="text-lg font-semibold text-foreground mb-2">Suas anotações aparecerão aqui</h3>
            <p className="text-muted-foreground mb-6">Registre suas reflexões, orações e pensamentos</p>
            <Button
              className="bg-primary text-primary-foreground py-2 px-6 rounded-lg font-medium"
              onClick={() => setIsAddingNote(true)}
              data-testid="button-add-first-note"
            >
              Criar primeira anotação
            </Button>
          </div>
        )}
      </div>

      {/* Edit Note Dialog */}
      <Dialog open={!!editingNote} onOpenChange={() => setEditingNote(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Anotação</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Título da anotação"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              data-testid="input-edit-note-title"
            />
            <Textarea
              placeholder="Escreva sua anotação aqui..."
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              rows={6}
              data-testid="textarea-edit-note-content"
            />
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setEditingNote(null)}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleUpdateNote}
                className="flex-1 bg-primary text-primary-foreground"
                data-testid="button-update-note"
              >
                Atualizar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
