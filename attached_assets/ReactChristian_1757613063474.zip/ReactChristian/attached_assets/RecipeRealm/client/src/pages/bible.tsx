import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ArrowLeft, Search, Volume2, ChevronLeft, ChevronRight } from "lucide-react";
import type { BibleBook } from "@shared/schema";

export default function BiblePage() {
  const [, setLocation] = useLocation();
  const [selectedBook, setSelectedBook] = useState("João");
  const [selectedChapter, setSelectedChapter] = useState("3");
  const [isTTSEnabled, setIsTTSEnabled] = useState(false);
  const [isBookSelectorOpen, setIsBookSelectorOpen] = useState(false);

  const { data: books, isLoading: booksLoading } = useQuery<BibleBook[]>({
    queryKey: ['/api/bible/books'],
  });

  const { data: currentBook, isLoading: bookLoading } = useQuery<BibleBook>({
    queryKey: ['/api/bible/books', selectedBook],
    enabled: !!selectedBook,
  });

  const toggleTTS = () => {
    if (!isTTSEnabled && currentBook && selectedChapter) {
      const chapters = currentBook.chapters as Array<{number: number, verses: string[]}>;
      const chapterContent = chapters.find(chapter => chapter.number === parseInt(selectedChapter));
      if (chapterContent && 'speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(chapterContent.verses.join(' '));
        utterance.lang = 'pt-BR';
        utterance.rate = 0.8;
        speechSynthesis.speak(utterance);
        setIsTTSEnabled(true);
        
        utterance.onend = () => setIsTTSEnabled(false);
      }
    } else {
      speechSynthesis.cancel();
      setIsTTSEnabled(false);
    }
  };

  const navigateChapter = (direction: 'prev' | 'next') => {
    if (!currentBook) return;
    
    const currentChapterNum = parseInt(selectedChapter);
    const chapters = currentBook.chapters as Array<{number: number, verses: string[]}>;
    const chapterNumbers = chapters.map(ch => ch.number).sort((a, b) => a - b);
    const currentIndex = chapterNumbers.findIndex(num => num === currentChapterNum);
    
    if (direction === 'prev' && currentIndex > 0) {
      setSelectedChapter(chapterNumbers[currentIndex - 1].toString());
    } else if (direction === 'next' && currentIndex < chapterNumbers.length - 1) {
      setSelectedChapter(chapterNumbers[currentIndex + 1].toString());
    }
  };

  const getCurrentChapterContent = () => {
    if (!currentBook || !selectedChapter) return null;
    const chapters = currentBook.chapters as Array<{number: number, verses: string[]}>;
    return chapters.find(chapter => chapter.number === parseInt(selectedChapter));
  };

  const chapterContent = getCurrentChapterContent();

  return (
    <div className="min-h-screen pb-20">
      <div className="bg-gradient-to-br from-primary/5 to-secondary/5">
        <div className="px-6 py-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Button
                variant="ghost"
                size="icon"
                className="mr-4 p-2 hover:bg-white/50 rounded-full tab-transition"
                onClick={() => setLocation('/home')}
                data-testid="button-back"
              >
                <ArrowLeft className="text-foreground" size={20} />
              </Button>
              <h1 className="text-xl font-semibold text-foreground">Bíblia Sagrada</h1>
            </div>
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="p-2 bg-white rounded-full soft-shadow"
                data-testid="button-search"
              >
                <Search className="text-muted-foreground" size={16} />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className={`p-2 bg-white rounded-full soft-shadow ${isTTSEnabled ? 'bg-primary text-primary-foreground' : ''}`}
                onClick={toggleTTS}
                data-testid="button-tts"
              >
                <Volume2 className="text-muted-foreground" size={16} />
              </Button>
            </div>
          </div>
          
          {/* Book Selection */}
          <Card className="card-shadow mb-4">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-foreground">Livro Atual</h3>
                <Dialog open={isBookSelectorOpen} onOpenChange={setIsBookSelectorOpen}>
                  <DialogTrigger asChild>
                    <Button 
                      variant="ghost" 
                      className="text-primary text-sm font-medium"
                      data-testid="button-select-book"
                    >
                      Alterar
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle>Selecionar Livro</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-2 py-4 max-h-96 overflow-y-auto">
                      {booksLoading ? (
                        <div className="space-y-2">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div key={i} className="h-10 bg-muted rounded animate-pulse"></div>
                          ))}
                        </div>
                      ) : (
                        books?.map((book) => (
                          <Button
                            key={book.name}
                            variant={selectedBook === book.name ? "default" : "outline"}
                            className="justify-start h-auto py-3 text-left"
                            onClick={() => {
                              setSelectedBook(book.name);
                              setSelectedChapter("1");
                              setIsBookSelectorOpen(false);
                            }}
                            data-testid={`button-book-${book.name.toLowerCase()}`}
                          >
                            {book.name}
                          </Button>
                        ))
                      )}
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-lg font-medium text-foreground" data-testid="text-current-book">
                  {selectedBook}
                </span>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Cap.</span>
                  <Select value={selectedChapter} onValueChange={setSelectedChapter}>
                    <SelectTrigger className="w-20" data-testid="select-chapter">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {(currentBook?.chapters as Array<{number: number, verses: string[]}> || []).map((chapter) => (
                        <SelectItem key={chapter.number} value={chapter.number.toString()}>
                          {chapter.number}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Chapter Content */}
          <Card className="card-shadow">
            <CardContent className="p-6">
              {bookLoading ? (
                <div className="animate-pulse space-y-4">
                  <div className="h-6 bg-muted rounded w-1/2 mx-auto"></div>
                  <div className="space-y-2">
                    <div className="h-4 bg-muted rounded"></div>
                    <div className="h-4 bg-muted rounded"></div>
                    <div className="h-4 bg-muted rounded w-5/6"></div>
                  </div>
                </div>
              ) : chapterContent ? (
                <>
                  <div className="text-center mb-6">
                    <h2 className="text-xl font-bold text-foreground" data-testid="text-chapter-title">
                      {selectedBook} {selectedChapter}
                    </h2>
                  </div>
                  
                  <div className="space-y-4 text-foreground leading-relaxed">
                    {chapterContent.verses.map((verse: string, index: number) => (
                      <div key={index} className="flex">
                        <span className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded mr-3 mt-1 flex-shrink-0">
                          {index + 1}
                        </span>
                        <p className="serif text-base">{verse}</p>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex gap-2 mt-6">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => navigateChapter('prev')}
                      disabled={selectedChapter === '1'}
                      data-testid="button-previous-chapter"
                    >
                      <ChevronLeft className="mr-1" size={16} />
                      Anterior
                    </Button>
                    <Button
                      className="flex-1 bg-primary text-primary-foreground"
                      onClick={() => navigateChapter('next')}
                      disabled={!currentBook || parseInt(selectedChapter) >= currentBook.chapters.length}
                      data-testid="button-next-chapter"
                    >
                      Próximo
                      <ChevronRight className="ml-1" size={16} />
                    </Button>
                  </div>
                </>
              ) : (
                <div className="text-center">
                  <p className="text-muted-foreground">Capítulo não encontrado</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
