import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLocalStorage, getDeviceId } from "@/lib/storage";
import { Cross } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Onboarding() {
  const [userName, setUserName] = useState("");
  const [userPreferences, setUserPreferences] = useLocalStorage('userPreferences', null);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (!userName.trim()) {
        toast({
          title: "Nome obrigatório",
          description: "Por favor, digite seu nome para continuar.",
          variant: "destructive",
        });
        return;
      }

      // Generate device ID safely
      const deviceId = getDeviceId();
      
      // Save user preferences
      const newPreferences = {
        userName: userName.trim(),
        currentDeviceId: deviceId,
        notifications: {
          dailyVerse: true,
          prayerReminders: true,
          morningPrayer: "07:00",
          eveningPrayer: "21:00",
        },
      };
      
      setUserPreferences(newPreferences);
      
      toast({
        title: "Bem-vindo!",
        description: `Olá, ${userName.trim()}! Sua jornada espiritual começa agora.`,
      });
      
      setLocation("/home");
    } catch (error) {
      console.error('Onboarding error:', error);
      toast({
        title: "Erro",
        description: "Houve um problema ao processar seus dados. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen gradient-bg px-6 py-8 flex flex-col justify-center">
      <div className="text-center mb-12">
        <div className="w-24 h-24 mx-auto mb-6 bg-white rounded-full flex items-center justify-center soft-shadow">
          <Cross className="text-4xl text-primary" size={48} />
        </div>
        <h1 className="text-3xl font-bold text-foreground mb-4">Bem-vindo</h1>
        <p className="text-lg text-muted-foreground leading-relaxed">
          Você não está sozinho.<br />
          <span className="font-semibold text-secondary">Viva com propósito.</span>
        </p>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <Label htmlFor="userName" className="block text-sm font-medium text-foreground mb-2">
            Como podemos te chamar?
          </Label>
          <Input
            id="userName"
            type="text"
            placeholder="Digite seu nome"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            className="w-full px-4 py-3 bg-white border border-border rounded-lg focus:ring-2 focus:ring-ring focus:border-transparent"
            data-testid="input-username"
          />
        </div>
        
        <Button 
          type="submit"
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-3 px-6 rounded-lg tab-transition"
          data-testid="button-start-journey"
        >
          Começar Jornada
        </Button>
      </form>
      
      <div className="mt-12 text-center">
        <p className="text-xs text-muted-foreground">
          Seus dados ficam salvos apenas no seu dispositivo
        </p>
      </div>
    </div>
  );
}
