import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLocalStorage } from "@/lib/storage";
import DailyVerse from "@/components/daily-verse";
import MoodCheck from "@/components/mood-check";
import { Bell, BookOpen, BookMarked, Music, Edit } from "lucide-react";

export default function Home() {
  const [userPreferences] = useLocalStorage('userPreferences', null);
  const [, setLocation] = useLocation();
  const userName = userPreferences?.userName || 'Amigo';

  const quickActions = [
    { name: 'Devocional', icon: BookOpen, path: '/devotional', testId: 'button-devotional' },
    { name: 'Bíblia', icon: BookMarked, path: '/bible', testId: 'button-bible' },
    { name: 'Hinário', icon: Music, path: '/hymns', testId: 'button-hymns' },
    { name: 'Anotações', icon: Edit, path: '/notes', testId: 'button-notes' },
  ];

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Bom dia';
    if (hour < 18) return 'Boa tarde';
    return 'Boa noite';
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <div className="gradient-bg px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-sm text-muted-foreground">{getGreeting()},</p>
            <h2 className="text-xl font-semibold text-foreground" data-testid="text-username">
              {userName}
            </h2>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="p-2 bg-white rounded-full soft-shadow"
            onClick={() => setLocation('/settings')}
            data-testid="button-notifications"
          >
            <Bell className="text-muted-foreground" size={20} />
          </Button>
        </div>
        
        <DailyVerse />
      </div>
      
      {/* Mood Check */}
      <div className="px-6 py-4">
        <MoodCheck />
      </div>
      
      {/* Quick Actions */}
      <div className="px-6 py-4">
        <h3 className="text-lg font-semibold text-foreground mb-4">Acesso Rápido</h3>
        <div className="grid grid-cols-2 gap-4">
          {quickActions.map((action) => (
            <Card
              key={action.path}
              className="cursor-pointer hover:bg-accent tab-transition"
              onClick={() => setLocation(action.path)}
            >
              <CardContent className="p-4 text-center">
                <action.icon className="text-2xl text-primary mb-2 mx-auto" size={32} />
                <p className="text-sm font-medium text-foreground" data-testid={action.testId}>
                  {action.name}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
