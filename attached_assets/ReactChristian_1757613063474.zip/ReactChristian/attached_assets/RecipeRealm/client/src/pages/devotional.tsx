import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Share, Bookmark } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Devotional } from "@shared/schema";

export default function DevotionalPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: devotional, isLoading, error } = useQuery<Devotional>({
    queryKey: ['/api/devotionals/daily'],
  });

  const handleShare = async () => {
    if (!devotional) return;
    
    try {
      await navigator.share({
        title: devotional.title,
        text: `${devotional.title}\n\n${devotional.content.substring(0, 200)}...`,
        url: window.location.href,
      });
    } catch {
      navigator.clipboard.writeText(`${devotional.title}\n\n${devotional.content}`);
      toast({
        title: "Copiado!",
        description: "Devocional copiado para a área de transferência",
      });
    }
  };

  const handleSave = () => {
    toast({
      title: "Salvo!",
      description: "Devocional salvo nas suas anotações",
    });
  };

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-destructive">Erro ao carregar devocional</p>
            <Button onClick={() => setLocation('/home')} className="mt-4">
              Voltar
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20">
      <div className="bg-gradient-to-br from-primary/10 to-secondary/10 px-6 py-8">
        <div className="flex items-center mb-6">
          <Button
            variant="ghost"
            size="icon"
            className="mr-4 p-2 hover:bg-white/50 rounded-full tab-transition"
            onClick={() => setLocation('/home')}
            data-testid="button-back"
          >
            <ArrowLeft className="text-foreground" size={20} />
          </Button>
          <h1 className="text-xl font-semibold text-foreground">Devocional Diário</h1>
        </div>
        
        {isLoading ? (
          <Card>
            <CardContent className="p-6">
              <div className="animate-pulse space-y-4">
                <div className="h-6 bg-muted rounded w-3/4"></div>
                <div className="h-4 bg-muted rounded w-1/2"></div>
                <div className="space-y-2">
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded w-5/6"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : devotional ? (
          <Card className="card-shadow">
            <CardContent className="p-6">
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold text-foreground mb-2" data-testid="text-devotional-title">
                  {devotional.title}
                </h2>
                <p className="text-sm text-muted-foreground">Baseado em {devotional.verseReference}</p>
              </div>
              
              <div className="prose prose-lg max-w-none text-foreground leading-relaxed space-y-4">
                {devotional.content.split('\n\n').map((paragraph, index) => (
                  <p key={index} className="text-base leading-relaxed">
                    {paragraph}
                  </p>
                ))}
                
                <div className="bg-muted p-4 rounded-lg mt-6">
                  <h4 className="font-semibold text-foreground mb-2">Oração do Dia:</h4>
                  <p className="italic text-muted-foreground">
                    {devotional.prayer}
                  </p>
                </div>
              </div>
              
              <div className="flex gap-3 mt-6">
                <Button
                  className="flex-1 bg-primary text-primary-foreground"
                  onClick={handleShare}
                  data-testid="button-share-devotional"
                >
                  <Share className="mr-2" size={16} />
                  Compartilhar
                </Button>
                <Button
                  className="flex-1 bg-secondary text-secondary-foreground"
                  onClick={handleSave}
                  data-testid="button-save-devotional"
                >
                  <Bookmark className="mr-2" size={16} />
                  Salvar
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-muted-foreground">Nenhum devocional disponível hoje</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
