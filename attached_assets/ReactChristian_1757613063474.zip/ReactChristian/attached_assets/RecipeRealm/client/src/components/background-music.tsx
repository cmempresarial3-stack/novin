import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Music, Play, Pause, Volume2, VolumeX } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { useQuery } from "@tanstack/react-query";

interface BackgroundTrack {
  id: string;
  name: string;
  url: string;
}

export default function BackgroundMusic() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState<BackgroundTrack | null>(null);
  const [volume, setVolume] = useState(0.3);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const { data: tracks } = useQuery<BackgroundTrack[]>({
    queryKey: ['/api/background-music'],
  });

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.volume = isMuted ? 0 : volume;
    audio.loop = true;
  }, [volume, isMuted]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio || !currentTrack) return;

    if (isPlaying) {
      audio.pause();
    } else {
      audio.play();
    }
    setIsPlaying(!isPlaying);
  };

  const selectTrack = (track: BackgroundTrack) => {
    const audio = audioRef.current;
    if (!audio) return;

    if (currentTrack?.id === track.id) {
      togglePlay();
      return;
    }

    setCurrentTrack(track);
    audio.src = track.url;
    
    if (isPlaying) {
      audio.play();
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (newVolume: number[]) => {
    setVolume(newVolume[0]);
    if (newVolume[0] > 0 && isMuted) {
      setIsMuted(false);
    }
  };

  if (!tracks || tracks.length === 0) {
    return null;
  }

  return (
    <>
      <audio 
        ref={audioRef} 
        onEnded={() => setIsPlaying(false)}
        onError={() => {
          setIsPlaying(false);
          // Could add toast notification here for user feedback
        }}
      />
      
      <div className="fixed bottom-20 right-6 z-50" style={{maxWidth: '375px', transform: 'translateX(-50%)', left: '50%'}}>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              size="lg"
              className={`p-3 rounded-full soft-shadow ${
                isPlaying ? 'bg-primary text-primary-foreground' : 'bg-white text-primary'
              }`}
              data-testid="button-background-music"
            >
              <Music size={20} />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80 p-4" side="top">
            <Card>
              <CardContent className="p-4">
                <h4 className="font-semibold text-foreground mb-3">Música de Fundo</h4>
                
                <div className="space-y-2 mb-4">
                  {tracks.map((track) => (
                    <Button
                      key={track.id}
                      variant={currentTrack?.id === track.id ? "default" : "outline"}
                      className="w-full justify-between text-left"
                      onClick={() => selectTrack(track)}
                      data-testid={`button-track-${track.id}`}
                    >
                      <span>{track.name}</span>
                      {currentTrack?.id === track.id && isPlaying && (
                        <Play size={14} />
                      )}
                    </Button>
                  ))}
                </div>
                
                {currentTrack && (
                  <div className="space-y-3 border-t pt-3">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={togglePlay}
                        data-testid="button-toggle-play"
                      >
                        {isPlaying ? <Pause size={14} /> : <Play size={14} />}
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={toggleMute}
                        data-testid="button-toggle-mute"
                      >
                        {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
                      </Button>
                      
                      <div className="flex-1">
                        <Slider
                          value={[isMuted ? 0 : volume]}
                          onValueChange={handleVolumeChange}
                          max={1}
                          step={0.1}
                          className="flex-1"
                          data-testid="slider-volume"
                        />
                      </div>
                    </div>
                    
                    <p className="text-xs text-muted-foreground">
                      Tocando: {currentTrack.name}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </PopoverContent>
        </Popover>
      </div>
    </>
  );
}
