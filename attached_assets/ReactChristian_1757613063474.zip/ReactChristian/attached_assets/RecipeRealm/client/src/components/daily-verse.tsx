import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Share } from "lucide-react";
import { useLocalStorage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import type { Verse } from "@shared/schema";

export default function DailyVerse() {
  const [userPreferences] = useLocalStorage('userPreferences', null);
  const { toast } = useToast();
  
  const { data: dailyVerse, isLoading, error } = useQuery<Verse>({
    queryKey: ['/api/verses/daily'],
    queryFn: async () => {
      const deviceId = userPreferences?.currentDeviceId || 'default';
      const response = await fetch(`/api/verses/daily?deviceId=${deviceId}`);
      if (!response.ok) throw new Error('Failed to fetch daily verse');
      return response.json();
    },
    enabled: !!userPreferences?.currentDeviceId,
  });

  const handleShare = async () => {
    if (!dailyVerse) return;
    
    const shareText = `"${dailyVerse.text}" - ${dailyVerse.reference}`;
    
    try {
      await navigator.share({
        title: 'Verso do Dia',
        text: shareText,
        url: window.location.href,
      });
    } catch {
      await navigator.clipboard.writeText(shareText);
      toast({
        title: "Verso copiado!",
        description: "O verso foi copiado para a área de transferência",
      });
    }
  };

  if (error) {
    return (
      <Card className="card-shadow">
        <CardContent className="p-6 text-center">
          <p className="text-destructive">Erro ao carregar verso diário</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white rounded-xl card-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Verso do Dia</h3>
          <Button
            variant="ghost"
            size="icon"
            className="text-secondary hover:text-secondary/80"
            onClick={handleShare}
            disabled={!dailyVerse}
            data-testid="button-share-verse"
          >
            <Share size={16} />
          </Button>
        </div>
        
        {isLoading ? (
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-muted rounded w-full"></div>
            <div className="h-4 bg-muted rounded w-5/6"></div>
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-3 bg-muted rounded w-1/3 mt-4"></div>
          </div>
        ) : dailyVerse ? (
          <>
            <blockquote className="serif text-lg text-foreground leading-relaxed mb-4" data-testid="text-daily-verse">
              "{dailyVerse.text}"
            </blockquote>
            <p className="text-sm text-muted-foreground font-medium" data-testid="text-verse-reference">
              {dailyVerse.reference}
            </p>
          </>
        ) : (
          <p className="text-muted-foreground italic">
            Verso não disponível no momento
          </p>
        )}
      </CardContent>
    </Card>
  );
}
