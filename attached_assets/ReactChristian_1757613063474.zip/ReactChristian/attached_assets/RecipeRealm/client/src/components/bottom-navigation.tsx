import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Home, BookMarked, Music, Edit, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

const navigationItems = [
  { path: '/home', icon: Home, label: 'Início', testId: 'nav-home' },
  { path: '/bible', icon: BookMarked, label: 'Bíblia', testId: 'nav-bible' },
  { path: '/hymns', icon: Music, label: 'Hinário', testId: 'nav-hymns' },
  { path: '/notes', icon: Edit, label: 'Notas', testId: 'nav-notes' },
  { path: '/settings', icon: Settings, label: 'Config', testId: 'nav-settings' },
];

export default function BottomNavigation() {
  const [location, setLocation] = useLocation();

  return (
    <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-[375px] bg-white border-t border-border">
      <div className="flex items-center justify-around py-2">
        {navigationItems.map((item) => {
          const isActive = location === item.path;
          
          return (
            <Button
              key={item.path}
              variant="ghost"
              className={cn(
                "flex flex-col items-center py-2 px-4 tab-transition h-auto",
                isActive 
                  ? "text-primary" 
                  : "text-muted-foreground hover:text-foreground"
              )}
              onClick={() => setLocation(item.path)}
              data-testid={item.testId}
            >
              <item.icon className="text-xl mb-1" size={20} />
              <span className="text-xs">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </div>
  );
}
