import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Smile, Heart, HandHelping, CloudRain } from "lucide-react";
import { useLocalStorage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import type { MoodEntry, Verse } from "@shared/schema";

const moodOptions = [
  { mood: 'peaceful', label: 'Em paz', icon: Smile, category: 'peace' },
  { mood: 'grateful', label: 'Grato', icon: Heart, category: 'gratitude' },
  { mood: 'anxious', label: 'Ansioso', icon: HandHelping, category: 'comfort' },
  { mood: 'struggling', label: 'Lutando', icon: CloudRain, category: 'strength' },
] as const;

export default function MoodCheck() {
  const [moodEntries, setMoodEntries] = useLocalStorage<MoodEntry[]>('moodEntries', []);
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const { toast } = useToast();

  const { data: verseForMood } = useQuery<Verse[]>({
    queryKey: ['/api/verses/category', selectedMood && moodOptions.find(m => m.mood === selectedMood)?.category],
    enabled: !!selectedMood,
  });

  const handleMoodSelect = async (moodType: string) => {
    setSelectedMood(moodType);
    
    const newEntry: MoodEntry = {
      mood: moodType as MoodEntry['mood'],
      timestamp: new Date().toISOString(),
    };

    setMoodEntries([newEntry, ...moodEntries.slice(0, 6)]);

    const moodOption = moodOptions.find(m => m.mood === moodType);
    if (moodOption && verseForMood && verseForMood.length > 0) {
      const randomVerse = verseForMood[Math.floor(Math.random() * verseForMood.length)];
      
      toast({
        title: `Entendemos que você está se sentindo ${moodOption.label.toLowerCase()}`,
        description: `"${randomVerse.text}" - ${randomVerse.reference}`,
        duration: 8000,
      });
    } else {
      toast({
        title: `Obrigado por compartilhar como você se sente`,
        description: "Deus conhece cada detalhe do seu coração.",
      });
    }
  };

  return (
    <Card className="soft-shadow">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Como você está se sentindo hoje?</h3>
        <div className="grid grid-cols-2 gap-3">
          {moodOptions.map((option) => (
            <Button
              key={option.mood}
              variant="ghost"
              className="flex items-center p-3 bg-muted rounded-lg hover:bg-primary hover:text-primary-foreground tab-transition h-auto"
              onClick={() => handleMoodSelect(option.mood)}
              data-testid={`button-mood-${option.mood}`}
            >
              <option.icon className="mr-3" size={20} />
              <span>{option.label}</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
