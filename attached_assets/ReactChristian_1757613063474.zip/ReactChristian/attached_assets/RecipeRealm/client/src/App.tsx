import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";
import Onboarding from "@/pages/onboarding";
import Devotional from "@/pages/devotional";
import Bible from "@/pages/bible";
import Hymns from "@/pages/hymns";
import Notes from "@/pages/notes";
import Settings from "@/pages/settings";
import BottomNavigation from "@/components/bottom-navigation";
import BackgroundMusic from "@/components/background-music";
import NotFound from "@/pages/not-found";
import { useLocalStorage } from "@/lib/storage";

function Router() {
  const [userPreferences] = useLocalStorage('userPreferences', null);
  const isOnboarded = userPreferences?.userName;

  return (
    <div className="mobile-container relative">
      <Switch>
        <Route path="/" component={isOnboarded ? Home : Onboarding} />
        <Route path="/home" component={Home} />
        <Route path="/onboarding" component={Onboarding} />
        <Route path="/devotional" component={Devotional} />
        <Route path="/bible" component={Bible} />
        <Route path="/hymns" component={Hymns} />
        <Route path="/notes" component={Notes} />
        <Route path="/settings" component={Settings} />
        <Route component={NotFound} />
      </Switch>
      
      {isOnboarded && (
        <>
          <BottomNavigation />
          <BackgroundMusic />
        </>
      )}
      
      <Toaster />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
